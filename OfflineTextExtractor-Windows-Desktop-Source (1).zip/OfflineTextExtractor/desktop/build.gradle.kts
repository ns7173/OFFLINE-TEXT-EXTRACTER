plugins {
    id("org.jetbrains.kotlin.jvm")
    application
}

version = "1.0.0"

kotlin {
    jvmToolchain(21)
}

application {
    mainClass.set("com.nitesh.offlineocr.desktop.MainKt")
}

tasks.register<Exec>("packageWindowsExe") {
    group = "distribution"
    description = "Create a Windows installer EXE using jpackage (requires Windows and WiX Toolset 3)."
    dependsOn(tasks.installDist)
    val installLib = layout.buildDirectory.dir("install/desktop/lib")
    val destination = layout.buildDirectory.dir("windows")
    doFirst {
        destination.get().asFile.mkdirs()
        val appJar = installLib.get().asFile.listFiles()
            ?.firstOrNull { it.name.startsWith("desktop-") && it.name.endsWith(".jar") }
            ?: error("Could not find desktop application JAR in ${installLib.get().asFile}")
        commandLine(
            "jpackage",
            "--type", "exe",
            "--name", "OfflineTextExtractor",
            "--app-version", project.version.toString(),
            "--input", installLib.get().asFile.absolutePath,
            "--main-jar", appJar.name,
            "--main-class", "com.nitesh.offlineocr.desktop.MainKt",
            "--dest", destination.get().asFile.absolutePath,
            "--win-menu",
            "--win-shortcut",
            "--description", "Offline image text extractor"
        )
    }
}
