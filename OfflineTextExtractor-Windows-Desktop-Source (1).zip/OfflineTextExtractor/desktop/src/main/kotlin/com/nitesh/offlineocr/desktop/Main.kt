package com.nitesh.offlineocr.desktop

import java.awt.BorderLayout
import java.awt.Dimension
import java.awt.FlowLayout
import java.awt.Font
import java.awt.GridBagConstraints
import java.awt.GridBagLayout
import java.awt.Insets
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.concurrent.CompletableFuture
import javax.swing.BorderFactory
import javax.swing.JButton
import javax.swing.JComboBox
import javax.swing.JFileChooser
import javax.swing.JFrame
import javax.swing.JLabel
import javax.swing.JOptionPane
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.JTextArea
import javax.swing.SwingUtilities
import javax.swing.SwingWorker
import javax.swing.filechooser.FileNameExtensionFilter

private class ExtractorWindow : JFrame("Offline Text Extractor — Windows") {
    private val selectedFile = JLabel("कोई image चुनें / Choose an image")
    private val language = JComboBox(arrayOf("Hindi + English (hin+eng)", "English (eng)"))
    private val result = JTextArea()
    private val chooseButton = JButton("Image चुनें / Choose image")
    private val scanButton = JButton("Text निकालें / Extract text")
    private val saveButton = JButton("TXT में Save करें / Save TXT")
    private var image: File? = null

    init {
        defaultCloseOperation = EXIT_ON_CLOSE
        minimumSize = Dimension(800, 560)
        setSize(1000, 700)
        setLocationRelativeTo(null)

        val top = JPanel(GridBagLayout())
        top.border = BorderFactory.createEmptyBorder(10, 12, 8, 12)
        val c = GridBagConstraints().apply {
            insets = Insets(4, 5, 4, 5)
            anchor = GridBagConstraints.WEST
            fill = GridBagConstraints.HORIZONTAL
        }
        c.gridx = 0; c.gridy = 0; c.weightx = 0.0; top.add(chooseButton, c)
        c.gridx = 1; c.weightx = 1.0; top.add(selectedFile, c)
        c.gridx = 0; c.gridy = 1; c.weightx = 0.0; top.add(JLabel("Language / भाषा:"), c)
        c.gridx = 1; c.weightx = 1.0; top.add(language, c)
        c.gridx = 2; c.weightx = 0.0; top.add(scanButton, c)

        result.font = Font(Font.SANS_SERIF, Font.PLAIN, 16)
        result.lineWrap = true
        result.wrapStyleWord = true
        result.border = BorderFactory.createEmptyBorder(10, 10, 10, 10)
        val center = JScrollPane(result)
        center.border = BorderFactory.createTitledBorder("Extracted text — editable")

        val bottom = JPanel(FlowLayout(FlowLayout.RIGHT))
        val hint = JLabel("Requires Tesseract OCR installed on Windows and available in PATH")
        bottom.add(hint)
        bottom.add(saveButton)

        layout = BorderLayout(8, 8)
        add(top, BorderLayout.NORTH)
        add(center, BorderLayout.CENTER)
        add(bottom, BorderLayout.SOUTH)

        chooseButton.addActionListener { pickImage() }
        scanButton.addActionListener { runOcr() }
        saveButton.addActionListener { saveText() }
    }

    private fun pickImage() {
        val chooser = JFileChooser().apply {
            dialogTitle = "Choose an image to read"
            fileFilter = FileNameExtensionFilter("Images (PNG, JPEG, TIFF, BMP)", "png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp")
        }
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            image = chooser.selectedFile
            selectedFile.text = image?.absolutePath ?: ""
        }
    }

    private fun runOcr() {
        val input = image ?: run {
            JOptionPane.showMessageDialog(this, "पहले image चुनें। / Choose an image first.", "No image", JOptionPane.INFORMATION_MESSAGE)
            return
        }
        val lang = if (language.selectedIndex == 0) "hin+eng" else "eng"
        chooseButton.isEnabled = false
        scanButton.isEnabled = false
        saveButton.isEnabled = false
        selectedFile.text = "OCR चल रहा है… / Reading image…"
        object : SwingWorker<String, Void>() {
            override fun doInBackground(): String = runTesseract(input, lang)
            override fun done() {
                chooseButton.isEnabled = true
                scanButton.isEnabled = true
                saveButton.isEnabled = true
                try {
                    result.text = get()
                    selectedFile.text = input.absolutePath
                    result.caretPosition = 0
                } catch (e: Exception) {
                    selectedFile.text = input.absolutePath
                    val cause = e.cause?.message ?: e.message ?: "Unknown error"
                    JOptionPane.showMessageDialog(
                        this@ExtractorWindow,
                        "$cause\n\nInstall Tesseract OCR and the selected language data, then ensure tesseract.exe is in PATH.",
                        "OCR failed", JOptionPane.ERROR_MESSAGE
                    )
                }
            }
        }.execute()
    }

    private fun runTesseract(file: File, lang: String): String {
        require(file.isFile) { "The selected image could not be found." }
        val process = try {
            ProcessBuilder("tesseract", file.absolutePath, "stdout", "-l", lang)
                .redirectErrorStream(false)
                .start()
        } catch (e: Exception) {
            throw IllegalStateException("Could not start Tesseract. Is it installed and on PATH?", e)
        }
        val stdout = CompletableFuture.supplyAsync {
            process.inputStream.use { it.readBytes().toString(StandardCharsets.UTF_8) }
        }
        val stderr = CompletableFuture.supplyAsync {
            process.errorStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        }
        val exit = process.waitFor()
        val output = stdout.get()
        val errors = stderr.get()
        if (exit != 0) throw IllegalStateException(errors.ifBlank { "Tesseract exited with code $exit." })
        return output.trimEnd()
    }

    private fun saveText() {
        val chooser = JFileChooser().apply {
            dialogTitle = "Save extracted text"
            selectedFile = File(image?.nameWithoutExtension?.plus(".txt") ?: "extracted-text.txt")
            fileFilter = FileNameExtensionFilter("Text files (*.txt)", "txt")
        }
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            var target = chooser.selectedFile
            if (!target.name.endsWith(".txt", ignoreCase = true)) target = File(target.parentFile, target.name + ".txt")
            try {
                target.writeText(result.text, StandardCharsets.UTF_8)
                JOptionPane.showMessageDialog(this, "Saved to:\n${target.absolutePath}", "Saved", JOptionPane.INFORMATION_MESSAGE)
            } catch (e: Exception) {
                JOptionPane.showMessageDialog(this, e.message ?: "Could not save file", "Save failed", JOptionPane.ERROR_MESSAGE)
            }
        }
    }
}

fun main() {
    SwingUtilities.invokeLater {
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName())
        } catch (_: Exception) { }
        ExtractorWindow().isVisible = true
    }
}
