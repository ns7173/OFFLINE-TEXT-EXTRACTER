package com.nitesh.offlineocr

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------
// Input: what OCR saw on one scanned page. Plain Kotlin, no Android classes, so the whole
// layout + export pipeline can be unit-tested on a normal JVM.
// ---------------------------------------------------------------------------------------

/** One recognized word with its box in pixels of the scanned page. */
/** A word with its position. [bold] and [underline] come from the page's ink (see [InkMeasure.styles]). */
data class OcrWord(
    val text: String, val left: Float, val top: Float, val right: Float, val bottom: Float,
    val bold: Boolean = false, val underline: Boolean = false,
)

class OcrPage(
    val width: Int,
    val height: Int,
    val words: List<OcrWord>,
    /** Ruling lines found on the page image (pixels). Empty when the page has none or they are not used. */
    val rules: List<Rule> = emptyList(),
)

// ---------------------------------------------------------------------------------------
// Output: the page described the way Word and Excel think about it.
// All distances are in "page widths": 1.0 is the full width of the scanned page.
// ---------------------------------------------------------------------------------------

enum class Align { LEFT, CENTER, RIGHT, JUSTIFY }

sealed interface Block {
    val spaceBefore: Float
    /** Top edge on the page, in page widths. Used to put tables and paragraphs back in reading order. */
    val top: Float
}

data class ParagraphBlock(
    /** Text of the paragraph. A TAB separates pieces that were far apart on the same line. */
    val text: String,
    val align: Align,
    /** Left indent measured from the page's text margin. */
    val indentLeft: Float,
    /** Extra indent of the first line (positive) or hanging indent (negative). */
    val firstLine: Float,
    override val spaceBefore: Float,
    /** Height of one text line; used to estimate the font size. */
    val fontHeight: Float,
    /** Left tab stops, measured from the page's text margin, where the pieces separated by TAB start. */
    val tabs: List<Float> = emptyList(),
    /** Distance between the lines of this paragraph as scanned (page widths); 0 when it has a single line. */
    val linePitch: Float = 0f,
    /** Number of scanned lines in the paragraph. */
    val lineCount: Int = 1,
    override val top: Float = 0f,
    /** Whole paragraph in bold (most of its words are bold on the scan). */
    val bold: Boolean = false,
    /** Whole paragraph underlined. */
    val underline: Boolean = false,
) : Block

data class TableBlock(
    /** Rectangular grid of cell texts. */
    val rows: List<List<String>>,
    val colWidths: List<Float>,
    val indentLeft: Float,
    override val spaceBefore: Float,
    val fontHeight: Float,
    /** False for tables that only line text up in columns (no grid lines wanted). */
    val bordered: Boolean = true,
    /** Alignment of the text in each column (amounts line up on their right edge); empty means all left. */
    val colAligns: List<Align> = emptyList(),
    override val top: Float = 0f,
) : Block

data class PageModel(
    /** Page height divided by page width. */
    val aspect: Float,
    val marginLeft: Float,
    val marginRight: Float,
    val marginTop: Float,
    /** Line spacing as a multiple of single spacing. */
    val lineMult: Float,
    val blocks: List<Block>,
)

/** User choices for how a scan is rebuilt in Word / Excel. */
data class ExportOptions(
    /** Detect tables from aligned columns. When off, aligned pieces stay in a paragraph separated by tabs. */
    val tables: Boolean = true,
    /** Draw cell borders on detected tables (Word and Excel). */
    val borders: Boolean = true,
    /** Keep every scanned line as its own paragraph instead of re-joining lines into flowing paragraphs. */
    val keepLineBreaks: Boolean = false,
    /**
     * Auto-tune: each detected table is checked, and one that does not look like a real data table
     * (for example a two-line signature block, or two columns of running text) keeps its column
     * positions but is drawn without borders, instead of as a bordered grid.
     */
    val auto: Boolean = true,
)

/** Width of an A4 page in points; scans are mapped onto A4 width. */
const val A4_WIDTH_PT = 595f

/**
 * A text line's box is a little taller than the font size (it spans ascenders to descenders,
 * and Devanagari matras make it taller still). This factor is an estimate; tune it if exported
 * text comes out consistently too big or too small. 0.8 was tuned on a real photographed Hindi court
 * document, where 0.9 gave text about 12% too large.
 */
const val FONT_FROM_HEIGHT = 0.8f

/** Estimated font size in half-points (Word's unit), from a text line's height. */
fun fontHalfPoints(lineHeight: Float): Int =
    ((lineHeight * A4_WIDTH_PT * FONT_FROM_HEIGHT).coerceIn(7f, 40f) * 2f).roundToInt()

/**
 * One scanned page: the words found in each selected area (a single entry when the whole page
 * was read). Every entry uses the pixel frame of the full, rotated page.
 */
class ScannedPage(
    val areas: List<OcrPage>,
    /** True when the user drew areas, false when the whole page was read. */
    val cropped: Boolean = false,
)

/**
 * Joins the layouts of several areas of one page into one page, stacked in the order given, so a
 * left column is followed by the right column. Each area keeps its own indents relative to its
 * own left edge.
 *
 * With [stackAtMargin] (used when the user drew areas) the result starts at ordinary page margins
 * instead of keeping the areas' position on the scanned page, so a box drawn in the middle of a
 * page does not end up indented. Without it (whole page read) a single area is returned as is.
 */
fun mergeModels(models: List<PageModel>, stackAtMargin: Boolean = false): PageModel {
    val filled = models.filter { it.blocks.isNotEmpty() }
    if (filled.isEmpty()) return models.firstOrNull() ?: PageModel(1.414f, 0.1f, 0.1f, 0.1f, 1f, emptyList())
    if (filled.size == 1 && !stackAtMargin) return filled[0]

    val blocks = ArrayList<Block>()
    filled.forEachIndexed { i, m ->
        m.blocks.forEachIndexed { j, b ->
            val gap = when {
                j == 0 && i > 0 -> 0.03f
                j == 0 && stackAtMargin -> 0f
                else -> b.spaceBefore
            }
            blocks.add(
                when (b) {
                    is ParagraphBlock -> b.copy(spaceBefore = gap)
                    is TableBlock -> b.copy(spaceBefore = gap)
                    is GridBlock -> b.copy(spaceBefore = gap)
                }
            )
        }
    }
    return PageModel(
        aspect = filled[0].aspect,
        marginLeft = if (stackAtMargin) 0.08f else filled.minOf { it.marginLeft },
        marginRight = if (stackAtMargin) 0.08f else filled.minOf { it.marginRight },
        marginTop = if (stackAtMargin) 0.08f else filled[0].marginTop,
        lineMult = filled.map { it.lineMult }.sorted()[filled.size / 2],
        blocks = blocks,
    )
}

// ---------------------------------------------------------------------------------------
// Layout analysis
// ---------------------------------------------------------------------------------------

object LayoutAnalyzer {

    /** A piece of a line; [count] words, of which the share [bold] and [underline] are styled. */
    private class Seg(
        val text: String, val left: Float, val right: Float,
        val count: Int = 1, val bold: Float = 0f, val underline: Float = 0f,
    )

    /**
     * One line of text. [marker] is a list number or bullet standing apart at the left ("1.", "(क)"); it is
     * not part of [segs], so a numbered paragraph's lines look like ordinary text lines.
     */
    private class Row(val top: Float, val bottom: Float, val segs: List<Seg>, val marker: Seg? = null) {
        val h: Float get() = bottom - top
        val cy: Float get() = (top + bottom) / 2f
        /** Where the line begins, counting the marker. */
        val left: Float get() = marker?.left ?: segs.first().left
        /** Where the line's own text begins. */
        val bodyLeft: Float get() = segs.first().left
        /** True when neighbouring lines start at the same place: a left-aligned block, so never "centered". */
        var pinned: Boolean = false
        val right: Float get() = segs.last().right
        val multi: Boolean get() = segs.size >= 2
        val text: String get() = segs.joinToString("\t") { it.text }
    }

    private class ParaAcc(val rows: MutableList<Row>, val space: Float)

    /** Largest vertical gap (in line heights) between rows that still belong to one table. */
    private const val MAX_TABLE_ROW_GAP = 1.6f

    fun analyze(page: OcrPage, options: ExportOptions = ExportOptions()): PageModel {
        val w = page.width.toFloat().coerceAtLeast(1f)
        val aspect = page.height / w

        // A table drawn with ruling lines is laid out as a grid; its words are taken out of the text flow.
        val grids = if (options.tables && page.rules.isNotEmpty()) {
            RuledGrid.buildAll(page.rules, page.words, w, page.height.toFloat())
        } else emptyList()
        val gridWords = grids.flatMap { it.consumed }.toSet()

        // Normalize to page widths and clean the text.
        val words = page.words.filter { it !in gridWords }.mapNotNull { src ->
            val text = src.text.replace(Regex("\\s+"), " ").trim()
            if (text.isEmpty() || src.right <= src.left || src.bottom <= src.top) null
            else OcrWord(text, src.left / w, src.top / w, src.right / w, src.bottom / w, src.bold, src.underline)
        }
        if (words.isEmpty()) {
            var empty = PageModel(aspect, 0.1f, 0.1f, 0.1f, 1f, emptyList())
            for (g in grids) empty = insertGrid(empty, g.block)
            return empty
        }

        val groups = groupIntoRows(words)
        val mh = median(groups.map { g -> g.maxOf { it.bottom } - g.minOf { it.top } })
        val rows = groups.map { splitMarker(toRow(it, mh)) }
        for (i in rows.indices) {
            val r = rows[i]
            if (r.multi) continue
            for (j in max(0, i - 2)..min(rows.size - 1, i + 2)) {
                if (j == i || rows[j].multi) continue
                if (abs(rows[j].bodyLeft - r.bodyLeft) <= 0.5f * mh && abs(rows[j].cy - r.cy) <= 3.5f * mh) r.pinned = true
            }
        }

        // Page geometry.
        val lefts = rows.map { it.left }.sorted()
        val rights = rows.map { it.right }.sorted()
        val textLeft = percentile(lefts, 0.05f)
        val textRight = rights.last()
        val fullRight = percentile(rights, 0.90f)
        val marginRight = (1f - textRight).coerceIn(0.03f, 0.40f)
        // Keep at least 0.2 page widths of text area, but let text that genuinely starts far right keep its margin.
        val marginLeft = textLeft.coerceIn(0.03f, max(0.03f, 1f - marginRight - 0.2f))
        val marginTop = rows.first().top.coerceIn(0.03f, 0.25f)

        // Typical gap and pitch between lines inside a paragraph.
        val gaps = ArrayList<Float>()
        val pitches = ArrayList<Float>()
        for (k in 1 until rows.size) {
            val gap = rows[k].top - rows[k - 1].bottom
            if (gap <= 0.6f * mh) {
                gaps.add(max(0f, gap))
                pitches.add(rows[k].cy - rows[k - 1].cy)
            }
        }
        val natural = if (gaps.isEmpty()) 0.25f * mh else median(gaps)
        val pitch = if (pitches.isEmpty()) mh + natural else median(pitches)
        val lineMult = (pitch / (1.25f * FONT_FROM_HEIGHT * mh)).coerceIn(1.0f, 2.0f)

        val blocks = ArrayList<Block>()
        var prevBottom = Float.NaN
        var para: ParaAcc? = null

        fun gapBefore(top: Float): Float =
            if (prevBottom.isNaN()) (top - marginTop).coerceAtLeast(0f)
            else (top - prevBottom - natural).coerceIn(0f, 0.15f)

        fun flush() {
            val p = para ?: return
            blocks.add(buildParagraph(p.rows, p.space, textLeft, textRight, marginLeft, mh).copy(top = p.rows.first().top))
            prevBottom = p.rows.last().bottom
            para = null
        }

        var i = 0
        while (i < rows.size) {
            val end = if (options.tables) tableRunEnd(rows, i, mh, options.auto) else -1
            if (end >= 0) {
                flush()
                val table = buildTable(rows.subList(i, end + 1), gapBefore(rows[i].top), marginLeft, mh, options.auto)
                if (table != null) {
                    blocks.add(table.copy(top = rows[i].top))
                    prevBottom = rows[end].bottom
                    i = end + 1
                    continue
                }
            }
            val r = rows[i]
            val cur = para
            if (cur != null && !options.keepLineBreaks && canContinue(cur.rows, r, textLeft, textRight, fullRight, mh)) {
                cur.rows.add(r)
            } else {
                flush()
                para = ParaAcc(mutableListOf(r), gapBefore(r.top))
            }
            i++
        }
        flush()

        var model = PageModel(aspect, marginLeft, marginRight, marginTop, lineMult, blocks)
        for (g in grids) model = insertGrid(model, g.block)
        return model
    }

    /** Puts a ruled table into reading order among the other blocks, and fixes the gaps around it. */
    private fun insertGrid(model: PageModel, grid: GridBlock): PageModel {
        val blocks = model.blocks.toMutableList()
        val idx = blocks.indexOfFirst { it.top > grid.top }.let { if (it < 0) blocks.size else it }
        val before = blocks.getOrNull(idx - 1)
        val gap = if (before == null) (grid.top - model.marginTop).coerceAtLeast(0f)
        else (grid.top - blockBottom(before)).coerceIn(0f, 0.15f)
        val placed = grid.copy(spaceBefore = gap, indentLeft = grid.indentLeft - model.marginLeft)
        blocks.add(idx, placed)
        blocks.getOrNull(idx + 1)?.let { after ->
            blocks[idx + 1] = withSpace(after, (after.top - placed.bottom).coerceIn(0f, 0.15f))
        }
        return model.copy(blocks = blocks)
    }

    private fun blockBottom(b: Block): Float = when (b) {
        is ParagraphBlock -> b.top + (b.lineCount - 1) * b.linePitch + b.fontHeight
        is TableBlock -> b.top + b.fontHeight * b.rows.size
        is GridBlock -> b.bottom
    }

    private fun withSpace(b: Block, s: Float): Block = when (b) {
        is ParagraphBlock -> b.copy(spaceBefore = s)
        is TableBlock -> b.copy(spaceBefore = s)
        is GridBlock -> b.copy(spaceBefore = s)
    }

    // ----- rows -----------------------------------------------------------------------

    /** Words whose vertical centres are close belong to the same text row. */
    private fun groupIntoRows(words: List<OcrWord>): List<List<OcrWord>> {
        val sorted = words.sortedBy { (it.top + it.bottom) / 2f }
        val groups = ArrayList<MutableList<OcrWord>>()
        var cy = 0f
        var heightSum = 0f
        for (wd in sorted) {
            val wcy = (wd.top + wd.bottom) / 2f
            val wh = wd.bottom - wd.top
            val g = groups.lastOrNull()
            if (g != null && abs(wcy - cy) <= 0.6f * max(heightSum / g.size, wh)) {
                cy = (cy * g.size + wcy) / (g.size + 1)
                heightSum += wh
                g.add(wd)
            } else {
                groups.add(mutableListOf(wd))
                cy = wcy
                heightSum = wh
            }
        }
        return groups
    }

    /** One segment from its words (in reading order), with the share of styled words. */
    private fun segOf(list: List<OcrWord>): Seg {
        val n = list.size.toFloat()
        return Seg(
            text = list.joinToString(" ") { it.text },
            left = list.first().left,
            right = list.maxOf { it.right },
            count = list.size,
            bold = list.count { it.bold } / n,
            underline = list.count { it.underline } / n,
        )
    }

    /** Splits a row into segments wherever there is a wide horizontal gap (e.g. between table cells). */
    private fun toRow(group: List<OcrWord>, mh: Float): Row {
        val ws = group.sortedBy { it.left }
        val top = ws.minOf { it.top }
        val bottom = ws.maxOf { it.bottom }
        val gapLimit = 1.5f * max(bottom - top, 0.7f * mh)

        val segs = ArrayList<Seg>()
        var cur = mutableListOf(ws[0])
        for (k in 1 until ws.size) {
            val wd = ws[k]
            if (wd.left - cur.maxOf { it.right } > gapLimit) {
                segs.add(segOf(cur))
                cur = mutableListOf(wd)
            } else {
                cur.add(wd)
            }
        }
        segs.add(segOf(cur))
        return Row(top, bottom, segs)
    }

    // ----- list markers ---------------------------------------------------------------------

    private val MARKER = Regex("^[(\\[]?([0-9\u0966-\u096F]{1,3}|[A-Za-z\u0905-\u0939])[.)\\]]?\\.?$")
    private val DIGITS_ONLY = Regex("^[0-9\u0966-\u096F]{1,3}$")

    /**
     * A line made of a short number or letter on its own at the left ("1.", "3", "(क)") followed by a long
     * stretch of text is a numbered paragraph: the marker is set aside so the text is read as one paragraph.
     */
    private fun splitMarker(row: Row): Row {
        if (row.segs.size != 2) return row
        val m = row.segs[0].text
        val body = row.segs[1].text
        val looksLikeMarker = DIGITS_ONLY.matches(m) || (MARKER.matches(m) && (m.contains('.') || m.contains(')')))
        val longBody = body.count { it == ' ' } >= 3 || body.length >= 25
        if (!looksLikeMarker || !longBody) return row
        return Row(row.top, row.bottom, listOf(row.segs[1]), row.segs[0])
    }

    // ----- alignment and paragraphs -------------------------------------------------------

    private fun alignOf(r: Row, textLeft: Float, textRight: Float, mh: Float): Align {
        val textW = textRight - textLeft
        val left = r.bodyLeft
        val width = r.right - left
        if (textW <= 0f || width >= 0.85f * textW) return Align.LEFT
        val h = max(r.h, mh)
        val leftOff = left - textLeft
        val rightOff = textRight - r.right
        // Short lines may sit a little off the exact middle (photos are rarely perfectly square).
        val centerTol = if (width < 0.35f * textW) max(h, 0.10f) else max(h, 0.015f)
        // A long line that runs to the right margin is a paragraph line (often an indented first line).
        return when {
            !r.pinned && abs(leftOff - rightOff) <= centerTol && min(leftOff, rightOff) > 0.025f -> Align.CENTER
            width < 0.6f * textW && rightOff <= max(3f * h, 0.06f) && leftOff > 3f * h -> Align.RIGHT
            else -> Align.LEFT
        }
    }

    /** True if row [r] is the next line of the paragraph made of [rows], rather than a new paragraph. */
    private fun canContinue(
        rows: List<Row>, r: Row,
        textLeft: Float, textRight: Float, fullRight: Float, mh: Float,
    ): Boolean {
        val prev = rows.last()
        if (prev.multi || r.multi) return false
        if (r.marker != null) return false                                            // a new numbered paragraph
        if (alignOf(rows.first(), textLeft, textRight, mh) != Align.LEFT) return false
        if (alignOf(r, textLeft, textRight, mh) != Align.LEFT) return false
        if (r.top - prev.bottom > 0.65f * (r.h + prev.h) / 2f) return false          // paragraph gap
        val ratio = r.h / prev.h
        if (ratio < 0.75f || ratio > 1.33f) return false                              // different font size
        if (prev.right < fullRight - 6f * mh) return false                             // previous line ended early
        return if (rows.size >= 2) {
            abs(r.left - rows[1].left) <= 1.2f * mh                                    // same body indent
        } else {
            // not a new indented start; after a numbered line the text may hang between marker and text
            val upper = if (prev.marker != null) prev.bodyLeft else prev.left + 1.2f * mh
            r.left <= upper && r.left >= textLeft - 1.2f * mh
        }
    }

    private fun buildParagraph(
        rows: List<Row>, space: Float,
        textLeft: Float, textRight: Float, marginLeft: Float, mh: Float,
    ): ParagraphBlock {
        val first = rows.first()
        val marker = first.marker
        val body = rows.joinToString(" ") { it.text }
        val text = if (marker != null) marker.text + "\t" + body else body
        // A box around one short word (no tall letters) reads smaller than the font really is, so very short
        // lines are not allowed to fall far below the page's usual line height.
        val measured = rows.map { it.h }.average().toFloat()
        // Devanagari matras make a line's box taller than its font. Two or more lines have a measured pitch, and
        // the font must leave room for it: the line spacing written to Word never goes below the font's own size.
        val pitch = if (rows.size >= 2) median(rows.zipWithNext { a, b -> b.cy - a.cy }) else 0f
        val capped = if (pitch > 0f) min(measured, 0.87f * pitch) else measured
        val fontHeight = if (body.length <= 12) max(capped, 0.9f * mh) else capped

        var align = if (first.multi) Align.LEFT else alignOf(first, textLeft, textRight, mh)
        if (align == Align.LEFT && rows.size >= 2) {
            // Justified text: most lines (all but the last) end at the same right edge. One line that ends
            // early because the next word did not fit does not spoil it.
            val rights = rows.dropLast(1).map { it.right }
            val edge = rights.maxOrNull()!!
            if (rights.count { it >= edge - 1.2f * mh } >= min(rights.size, max(2, (rights.size * 0.6f).roundToInt()))) align = Align.JUSTIFY
        }

        var indent = 0f
        var firstLine = 0f
        var tabs = emptyList<Float>()
        if (align == Align.LEFT || align == Align.JUSTIFY) {
            if (marker != null) {
                // Number at the left, text further in: later lines hang at their own indent.
                val cont = if (rows.size >= 2) rows[1].left else marker.left
                indent = max(0f, cont - marginLeft)
                firstLine = max(marker.left - cont, -indent)
                tabs = listOf(max(0f, first.bodyLeft - marginLeft))
            } else {
                val bodyLeft = if (rows.size >= 2) rows[1].left else first.left
                indent = max(0f, bodyLeft - marginLeft)
                val d = first.left - bodyLeft
                if (abs(d) > 0.5f * mh) firstLine = max(d, -indent)
                // Pieces far apart on one line (label ........ label) keep their positions with tab stops.
                if (first.multi) tabs = first.segs.drop(1).map { max(0f, it.left - marginLeft) }
            }
        }
        // A paragraph is bold (or underlined) when nearly all of its words are; mixed lines stay plain.
        val pieces = rows.flatMap { it.segs }
        val total = max(1, pieces.sumOf { it.count }).toFloat()
        val boldAll = pieces.sumOf { it.bold.toDouble() * it.count } / total >= 0.8
        val underlineAll = pieces.sumOf { it.underline.toDouble() * it.count } / total >= 0.8
        return ParagraphBlock(
            text, align, indent, firstLine, space, fontHeight, tabs, pitch, rows.size,
            bold = boldAll, underline = underlineAll,
        )
    }

    // ----- tables ----------------------------------------------------------------------

    /**
     * A table is a run of rows that each have two or more separated segments. A single-segment
     * row sandwiched between two such rows (a wrapped cell, a spanning label) stays in the table.
     * Returns the index of the last row of the run, or -1 if [start] does not begin one.
     */
    private fun tableRunEnd(rows: List<Row>, start: Int, mh: Float, auto: Boolean): Int {
        if (!rows[start].multi) return -1
        var end = start
        var k = start + 1
        while (k < rows.size) {
            if (rows[k].top - rows[end].bottom > MAX_TABLE_ROW_GAP * mh) break
            if (rows[k].multi) {
                end = k
                k++
            } else if (k + 1 < rows.size && rows[k + 1].multi &&
                rows[k + 1].top - rows[k].bottom <= MAX_TABLE_ROW_GAP * mh &&
                (!auto || startsAtColumn(rows[k], rows.subList(start, end + 1), mh))
            ) {
                end = k + 1
                k += 2
            } else {
                break
            }
        }
        val labelRows = (start..end).count { rows[it].multi }
        if (auto && end > start && labelRows <= 3) {
            // Label on the left, details on the right ("प्रथम पक्षकार | name, father, caste, address ..."): the
            // details run on in lines that start where the right-hand column starts; they belong to the table.
            // Only for a block with a few label rows: below a long data table, a paragraph that happens to
            // start under one of its columns must not be pulled in.
            val columnLefts = (start..end).map { rows[it] }.filter { it.multi }.flatMap { r -> r.segs.drop(1).map { it.left } }
            var k2 = end + 1
            while (k2 < rows.size) {
                val r = rows[k2]
                if (r.multi || r.top - rows[end].bottom > MAX_TABLE_ROW_GAP * mh) break
                if (columnLefts.none { abs(it - r.left) <= 1.2f * mh || abs(it - r.bodyLeft) <= 1.2f * mh }) break
                end = k2
                k2++
            }
        }
        return if (end > start) end else -1
    }

    /**
     * True if a single-piece line starts where one of the table's columns starts (a wrapped cell). A line
     * that starts elsewhere, such as a centered "versus" between two rows of party names, is not part of it.
     */
    private fun startsAtColumn(row: Row, run: List<Row>, mh: Float): Boolean =
        run.any { r -> r.segs.any { abs(it.left - row.bodyLeft) <= 1.2f * mh } }

    private fun buildTable(run: List<Row>, space: Float, marginLeft: Float, mh: Float, auto: Boolean): TableBlock? {
        val multiRows = run.filter { it.multi }
        if (multiRows.size < 2) return null

        // Columns are the horizontal bands covered by segments of the multi-segment rows.
        val intervals = multiRows.flatMap { r -> r.segs.map { floatArrayOf(it.left, it.right) } }.sortedBy { it[0] }
        val bands = ArrayList<FloatArray>()
        for (iv in intervals) {
            val last = bands.lastOrNull()
            if (last != null && iv[0] <= last[1]) last[1] = max(last[1], iv[1])
            else bands.add(floatArrayOf(iv[0], iv[1]))
        }
        if (bands.size < 2) return null

        fun bandAt(x: Float): Int {
            for (b in bands.indices) if (x >= bands[b][0] && x <= bands[b][1]) return b
            return bands.indices.minByOrNull { b -> min(abs(x - bands[b][0]), abs(x - bands[b][1])) } ?: 0
        }

        // Lines that run on inside a column make it as wide as they are.
        for (r in run) if (!r.multi) {
            val b = bandAt(r.left)
            bands[b][1] = max(bands[b][1], r.right)
        }

        val grid = ArrayList<List<String>>()
        val colLefts = List(bands.size) { ArrayList<Float>() }
        val colRights = List(bands.size) { ArrayList<Float>() }
        for ((ri, r) in run.withIndex()) {
            val cells = Array(bands.size) { "" }
            var lastIdx = -1
            for (s in r.segs) {
                val idx = if (r.multi) bandAt((s.left + s.right) / 2f) else bandAt(r.left)
                val t = if (r.marker != null) r.marker.text + " " + s.text else s.text
                if (cells[idx].isEmpty()) cells[idx] = t
                // Neighbouring pieces in one column (a value split by dotted leaders) are one cell; pieces that
                // are not neighbours mean the columns are not real.
                else if (idx == lastIdx) cells[idx] = cells[idx] + " " + t
                else return null
                lastIdx = idx
                if (ri > 0 || run.size < 3) { colLefts[idx].add(s.left); colRights[idx].add(s.right) }
            }
            grid.add(cells.toList())
        }

        // A column in which only one cell (or none) has any text is no column.
        if (auto && grid.size >= 3) for (c in 0 until bands.size) if (grid.count { it[c].isNotEmpty() } <= 1) return null

        // Short answers ("No", "NA") that trail ragged lines of running text are not a column: their left
        // and right edges do not line up. Such a block is a list of paragraphs, not a table.
        if (auto) for (c in 1 until bands.size) {
            val l = colLefts[c]
            val rt = colRights[c]
            if (l.size >= 3 && (l.max() - l.min()) > 3f * mh && (rt.max() - rt.min()) > 3f * mh) {
                val cells = grid.map { it[c] }.filter { it.isNotEmpty() }
                if (cells.sumOf { it.length } / cells.size.toFloat() <= 12f) return null
            }
        }

        // A grid of many very narrow columns (a ruled register) wraps every cell into a tall, thin strip. Word
        // cannot fit that on a page, so such a block is kept as lines of text.
        if (auto && bands.size >= 6) {
            val avgW = (bands.last()[1] - bands.first()[0]) / bands.size
            if (avgW < 0.06f) return null
        }

        val bordered = !auto || looksLikeDataTable(grid)
        val pad = 0.4f * mh
        val bounds = FloatArray(bands.size + 1)
        bounds[0] = bands.first()[0] - pad
        // Bordered tables put the lines midway between columns. Borderless ones are only aligned text, so
        // each column starts where its text starts and the text keeps its place on the page.
        for (k in 1 until bands.size) bounds[k] = if (bordered) (bands[k - 1][1] + bands[k][0]) / 2f else bands[k][0] - pad
        bounds[bands.size] = bands.last()[1] + pad
        val widths = List(bands.size) { bounds[it + 1] - bounds[it] }

        // A column too narrow for about two letters cannot hold its text: these lines are not a table.
        if (widths.any { it < 1.2f * mh }) return null

        return TableBlock(
            rows = grid,
            colWidths = widths,
            indentLeft = max(0f, bounds[0] - marginLeft),
            spaceBefore = space,
            fontHeight = median(run.map { it.h }),
            bordered = bordered,
            colAligns = List(bands.size) { c ->
                // Amounts and dates down a column share their right edge; text shares its left edge.
                val l = colLefts[c]
                val rt = colRights[c]
                val body = grid.drop(if (run.size >= 3) 1 else 0).map { it[c] }.filter { it.isNotEmpty() }
                val mostlyNumbers = body.isNotEmpty() && body.count { isNumberCell(it) } * 2 > body.size
                if (l.size >= 3 && mostlyNumbers && (rt.max() - rt.min()) < 0.5f * (l.max() - l.min()) && (rt.max() - rt.min()) <= mh) Align.RIGHT
                else Align.LEFT
            },
        )
    }

    /**
     * A data table has a few rows that are mostly filled in, or it holds numbers across several rows.
     * Short two-row blocks without numbers (signature lines, "Appellant / Respondent" labels) and
     * grids whose cells are long running text are layout, not data: they keep their columns but get no borders.
     */
    internal fun looksLikeDataTable(grid: List<List<String>>): Boolean {
        val cells = grid.flatten()
        if (cells.isEmpty()) return false
        val filled = cells.filter { it.isNotEmpty() }
        val fill = filled.size.toFloat() / cells.size
        val avgLen = filled.sumOf { it.length } / filled.size.coerceAtLeast(1)
        if (avgLen > 60) return false
        // Numbers in at least two different columns (number, date, amount) mean data; a single column of
        // amounts next to labels ("बाजार भावः  8,50,000/-") is just a form line.
        val numericCols = grid.flatMap { r -> r.withIndex().filter { (_, c) -> isNumberCell(c) }.map { it.index } }.toSet()
        val numeric = cells.count { isNumberCell(it) }
        // A grid of short text cells (the four sides of a plot: "उत्तर दिशा में | खसरा नं. 8/2") is a real table;
        // longer cells (a person's name, father, address) are a form laid out in columns, so no lines.
        val shortCells = avgLen <= 24
        return (grid.size >= 3 && fill >= 0.8f && shortCells) || (grid.size >= 2 && numeric >= 2 && numericCols.size >= 2)
    }

    // ----- helpers ---------------------------------------------------------------------

    /** A cell that is only a number, date or amount ("123/4", "0.405", "30,000/-", "16/03/2026", "8,50,000/- रू."); a label with digits ("मो. नं.-97545") is not. */
    private fun isNumberCell(c: String): Boolean {
        val t = c.replace(CURRENCY, "")
        return t.any { it.isDigit() } && t.none { it.isLetter() }
    }

    private val CURRENCY = Regex("(?i)rs\\.?|inr|\u0930\u0941\\.?|\u0930\u0942\\.?|\u20b9")

    private fun median(v: List<Float>): Float {
        if (v.isEmpty()) return 0f
        val s = v.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
    }

    private fun percentile(sorted: List<Float>, p: Float): Float = sorted[((sorted.size - 1) * p).toInt()]
}
