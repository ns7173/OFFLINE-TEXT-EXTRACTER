package com.nitesh.offlineocr

import java.io.InputStream
import java.io.OutputStream
import java.util.Locale

/**
 * A saved scan: the text plus every word with its position, so Word / Excel export can be redone
 * later without scanning again, and so a scan can be sent to someone to improve the layout rules.
 * Plain Kotlin (no Android classes) with a tiny built-in JSON reader/writer.
 */
class ScanData(val text: String, val pages: List<ScannedPage>)

object ScanDataIO {
    private const val FORMAT = "offline-text-extractor-scan"
    // Version 2 adds the ruling lines of each area ("rules"), so a saved scan can be laid out with its tables again.
    private const val VERSION = 2

    fun write(data: ScanData, out: OutputStream) {
        val sb = StringBuilder()
        sb.append("{\"format\":\"").append(FORMAT).append("\",\"version\":").append(VERSION)
        sb.append(",\"text\":"); quote(sb, data.text)
        sb.append(",\"pages\":[")
        data.pages.forEachIndexed { pi, sp ->
            if (pi > 0) sb.append(',')
            sb.append("{\"cropped\":").append(sp.cropped).append(",\"areas\":[")
            sp.areas.forEachIndexed { ai, a ->
                if (ai > 0) sb.append(',')
                sb.append("{\"width\":").append(a.width).append(",\"height\":").append(a.height).append(",\"words\":[\n")
                a.words.forEachIndexed { wi, w ->
                    if (wi > 0) sb.append(",\n")
                    sb.append('['); quote(sb, w.text)
                    sb.append(',').append(num(w.left)).append(',').append(num(w.top))
                    sb.append(',').append(num(w.right)).append(',').append(num(w.bottom))
                    // Optional style bits: 1 = bold, 2 = underline. Left out for plain words.
                    if (w.bold || w.underline) sb.append(',').append((if (w.bold) 1 else 0) + (if (w.underline) 2 else 0))
                    sb.append(']')
                }
                sb.append("\n],\"rules\":[")
                a.rules.forEachIndexed { ri, r ->
                    if (ri > 0) sb.append(',')
                    sb.append('[').append(if (r.horizontal) 1 else 0).append(',').append(r.pos)
                    sb.append(',').append(r.from).append(',').append(r.to).append(',').append(r.thickness).append(']')
                }
                sb.append("]}")
            }
            sb.append("]}")
        }
        sb.append("]}\n")
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
        out.flush()
    }

    /** Throws [IllegalArgumentException] with a readable message if the file is not a saved scan. */
    fun read(input: InputStream): ScanData {
        val root = try {
            Parser(input.readBytes().toString(Charsets.UTF_8)).parseDocument()
        } catch (e: IllegalArgumentException) {
            throw IllegalArgumentException("This is not a saved scan file")
        }
        val obj = root as? Map<*, *> ?: throw IllegalArgumentException("This is not a saved scan file")
        if (obj["format"] != FORMAT) throw IllegalArgumentException("This is not a saved scan file")
        val version = (obj["version"] as? Double)?.toInt() ?: 0
        if (version > VERSION) throw IllegalArgumentException("This scan was saved by a newer version of the app")
        val text = obj["text"] as? String ?: ""
        val pages = (obj["pages"] as? List<*>).orEmpty().map { p ->
            val po = p as? Map<*, *> ?: throw IllegalArgumentException("Saved scan is damaged")
            val areas = (po["areas"] as? List<*>).orEmpty().map { a ->
                val ao = a as? Map<*, *> ?: throw IllegalArgumentException("Saved scan is damaged")
                val words = (ao["words"] as? List<*>).orEmpty().map { w ->
                    val l = w as? List<*> ?: throw IllegalArgumentException("Saved scan is damaged")
                    if (l.size != 5 && l.size != 6) throw IllegalArgumentException("Saved scan is damaged")
                    val style = if (l.size == 6) i(l[5]) else 0
                    OcrWord(
                        l[0] as? String ?: throw IllegalArgumentException("Saved scan is damaged"),
                        f(l[1]), f(l[2]), f(l[3]), f(l[4]),
                        bold = (style and 1) != 0, underline = (style and 2) != 0,
                    )
                }
                val rules = (ao["rules"] as? List<*>).orEmpty().map { r ->
                    val l = r as? List<*> ?: throw IllegalArgumentException("Saved scan is damaged")
                    if (l.size != 5) throw IllegalArgumentException("Saved scan is damaged")
                    Rule(
                        horizontal = i(l[0]) == 1, pos = i(l[1]), from = i(l[2]), to = i(l[3]), thickness = i(l[4]),
                    )
                }
                OcrPage((ao["width"] as? Double)?.toInt() ?: 1, (ao["height"] as? Double)?.toInt() ?: 1, words, rules)
            }
            ScannedPage(areas, po["cropped"] == true)
        }
        return ScanData(text, pages)
    }

    private fun f(v: Any?): Float = (v as? Double)?.toFloat() ?: throw IllegalArgumentException("Saved scan is damaged")

    private fun i(v: Any?): Int = (v as? Double)?.toInt() ?: throw IllegalArgumentException("Saved scan is damaged")

    private fun num(v: Float): String = String.format(Locale.US, "%.1f", v)

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c < ' ' -> sb.append(String.format("\\u%04x", c.code))
            else -> sb.append(c)
        }
        sb.append('"')
    }

    /** Minimal JSON reader: objects, arrays, strings, numbers (as Double), true/false/null. */
    private class Parser(val s: String) {
        var i = 0

        fun parseDocument(): Any? {
            val v = value()
            ws()
            if (i != s.length) fail()
            return v
        }

        fun fail(): Nothing = throw IllegalArgumentException("bad json at $i")

        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }

        fun value(): Any? {
            ws()
            if (i >= s.length) fail()
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) number() else fail()
            }
        }

        fun lit(word: String, v: Any?): Any? {
            if (!s.startsWith(word, i)) fail()
            i += word.length
            return v
        }

        fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
            return s.substring(st, i).toDoubleOrNull() ?: fail()
        }

        fun str(): String {
            i++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) fail()
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) fail()
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000c')
                            'u' -> {
                                if (i + 4 > s.length) fail()
                                sb.append(s.substring(i, i + 4).toIntOrNull(16)?.toChar() ?: fail())
                                i += 4
                            }
                            else -> fail().also { e.hashCode() }
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            ws()
            if (i < s.length && s[i] == ']') { i++; return out }
            while (true) {
                out.add(value())
                ws()
                if (i >= s.length) fail()
                if (s[i] == ',') { i++; continue }
                if (s[i] == ']') { i++; return out }
                fail()
            }
        }

        fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            ws()
            if (i < s.length && s[i] == '}') { i++; return out }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') fail()
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') fail()
                i++
                out[k] = value()
                ws()
                if (i >= s.length) fail()
                if (s[i] == ',') { i++; continue }
                if (s[i] == '}') { i++; return out }
                fail()
            }
        }
    }
}

