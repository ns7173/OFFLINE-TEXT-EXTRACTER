package com.nitesh.offlineocr

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Escapes text for XML and drops characters that are not legal in XML 1.0. */
internal fun xmlEscape(s: String): String {
    val sb = StringBuilder(s.length + 16)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        when {
            c == '&' -> sb.append("&amp;")
            c == '<' -> sb.append("&lt;")
            c == '>' -> sb.append("&gt;")
            c == '"' -> sb.append("&quot;")
            c.isHighSurrogate() && i + 1 < s.length && s[i + 1].isLowSurrogate() -> {
                sb.append(c).append(s[i + 1])
                i++
            }
            c.isSurrogate() -> Unit // lone surrogate, not legal in XML
            c.code < 0x20 && c != '\t' && c != '\n' && c != '\r' -> Unit
            c.code == 0xFFFE || c.code == 0xFFFF -> Unit
            else -> sb.append(c)
        }
        i++
    }
    return sb.toString()
}

/** Minimal zip writer for Office Open XML packages. The caller owns (and closes) [out]. */
internal class ZipBuilder(out: OutputStream) {
    private val zip = ZipOutputStream(out)

    fun add(name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    fun finish() {
        zip.finish()
        zip.flush()
    }
}
