package com.nitesh.offlineocr

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tan

// Pure Kotlin (no Android classes) so it can be tested on a normal JVM.

data class Pt(val x: Float, val y: Float)

/**
 * The four corners of the page inside a photo, as fractions (0..1) of the photo's width and height,
 * in the order top-left, top-right, bottom-right, bottom-left. The area between them is flattened
 * into a straight rectangle.
 */
data class Quad(val tl: Pt, val tr: Pt, val br: Pt, val bl: Pt) {

    fun isFull(eps: Float = 0.004f): Boolean =
        near(tl, 0f, 0f, eps) && near(tr, 1f, 0f, eps) && near(br, 1f, 1f, eps) && near(bl, 0f, 1f, eps)

    /**
     * The same page corners after the photo is turned 90 degrees clockwise. The corner roles shift
     * by one, so the flattened result turns clockwise together with the photo.
     */
    fun rotatedCw(): Quad = Quad(tl = bl.turn(), tr = tl.turn(), br = tr.turn(), bl = br.turn())

    /** Size of the quadrilateral as a fraction of the photo (shoelace formula). */
    fun area(): Float {
        val p = listOf(tl, tr, br, bl)
        var s = 0f
        for (i in p.indices) {
            val a = p[i]
            val b = p[(i + 1) % 4]
            s += a.x * b.y - b.x * a.y
        }
        return abs(s) / 2f
    }

    /** True when the corners form a proper convex four-sided shape (no crossed or folded corners). */
    fun isConvex(): Boolean {
        val p = listOf(tl, tr, br, bl)
        var sign = 0
        for (i in p.indices) {
            val a = p[i]
            val b = p[(i + 1) % 4]
            val c = p[(i + 2) % 4]
            val cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
            val s = if (cross > 1e-6f) 1 else if (cross < -1e-6f) -1 else 0
            if (s == 0) return false
            if (sign == 0) sign = s else if (s != sign) return false
        }
        return true
    }

    companion object {
        val FULL = Quad(Pt(0f, 0f), Pt(1f, 0f), Pt(1f, 1f), Pt(0f, 1f))
    }
}

private fun Pt.turn() = Pt(1f - y, x)
private fun near(p: Pt, x: Float, y: Float, eps: Float) = abs(p.x - x) <= eps && abs(p.y - y) <= eps

/** A grayscale picture: [px] holds brightness 0..255, row by row. */
class GrayImage(val width: Int, val height: Int, val px: IntArray)

object PageGeometry {

    // ----- tilt (rotation of the text lines) ---------------------------------------------------

    /**
     * How far the text lines are turned clockwise, in degrees (positive means the lines descend
     * towards the right). To straighten the page, turn it by the negative of this value.
     * Returns null when the picture has no clear lines of text.
     *
     * Method: for each candidate angle, count dark pixels per horizontal row after shearing by that
     * angle. Straight text lines pile up in few rows, so the sharpest row histogram wins.
     */
    fun estimateSkew(img: GrayImage, maxAngle: Float = 15f): Float? {
        val dots = darkDots(img) ?: return null

        // Coarse search, then refine around the best angle.
        var best = 0f
        var bestScore = -1.0
        var sum = 0.0
        var n = 0
        var a = -maxAngle
        while (a <= maxAngle + 1e-4f) {
            val s = score(dots, img.height, a)
            sum += s
            n++
            if (s > bestScore) { bestScore = s; best = a }
            a += 0.5f
        }
        val mean = sum / n
        if (bestScore < 1.10 * mean) return null // no sharp peak: not enough straight text lines

        val center = best
        var refined = center
        var refinedScore = bestScore
        a = center - 0.5f
        while (a <= center + 0.5f + 1e-4f) {
            val s = score(dots, img.height, a)
            if (s > refinedScore) { refinedScore = s; refined = a }
            a += 0.1f
        }
        return refined
    }

    private class Dots(val xs: IntArray, val ys: IntArray, val n: Int, val maxX: Int)

    /** Finds text-like dark pixels (darker than their surroundings), ignoring the outer border of the picture. */
    private fun darkDots(img: GrayImage): Dots? {
        val w = img.width
        val h = img.height
        if (w < 40 || h < 40) return null

        // Integral image for fast local averages.
        val integral = IntArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                row += img.px[y * w + x]
                integral[(y + 1) * (w + 1) + x + 1] = integral[y * (w + 1) + x + 1] + row
            }
        }
        val r = max(6, min(w, h) / 40)
        val mx = (w * 0.06f).toInt()
        val my = (h * 0.06f).toInt()

        val mask = BooleanArray(w * h)
        var count = 0
        for (y in my until h - my) {
            val y0 = max(0, y - r)
            val y1 = min(h - 1, y + r)
            for (x in mx until w - mx) {
                val x0 = max(0, x - r)
                val x1 = min(w - 1, x + r)
                val area = (x1 - x0 + 1) * (y1 - y0 + 1)
                val sum = integral[(y1 + 1) * (w + 1) + x1 + 1] - integral[y0 * (w + 1) + x1 + 1] -
                    integral[(y1 + 1) * (w + 1) + x0] + integral[y0 * (w + 1) + x0]
                if (img.px[y * w + x] < sum / area - 14) {
                    mask[y * w + x] = true
                    count++
                }
            }
        }
        if (count < 300 || count > 0.4f * w * h) return null

        val xs = IntArray(count)
        val ys = IntArray(count)
        var k = 0
        var maxX = 0
        for (y in 0 until h) for (x in 0 until w) if (mask[y * w + x]) {
            xs[k] = x; ys[k] = y; k++
            if (x > maxX) maxX = x
        }
        return Dots(xs, ys, count, maxX)
    }

    private fun score(d: Dots, height: Int, angleDeg: Float): Double {
        val t = tan(Math.toRadians(angleDeg.toDouble()))
        val offset = (d.maxX * abs(t)).toInt() + 2
        val bins = IntArray(height + 2 * offset + 4)
        for (i in 0 until d.n) {
            val row = floor(d.ys[i] - d.xs[i] * t).toInt() + offset
            bins[row]++
        }
        var s = 0.0
        for (c in bins) s += c.toDouble() * c
        return s
    }

    // ----- page edges (where the paper is inside the photo) -------------------------------------

    /**
     * Finds the four corners of a light page lying on a darker background. Returns [Quad.FULL] if the
     * page already fills the picture, and null if no clear page was found (the user then drags the
     * corners by hand). Works best on a small picture (about 250 px on the long side).
     */
    fun detectPageQuad(img: GrayImage): Quad? {
        val w = img.width
        val h = img.height
        val total = w * h
        if (w < 32 || h < 32) return null

        val hist = IntArray(256)
        for (v in img.px) hist[v.coerceIn(0, 255)]++
        val thr = otsu(hist, total)
        val bright = BooleanArray(total) { img.px[it] > thr }
        val frac = bright.count { it }.toFloat() / total
        if (frac >= 0.97f) return Quad.FULL
        if (frac < 0.15f) return null

        // Close small dark gaps (text, thin rules) so the page stays one piece.
        val grown = dilate(bright, w, h, 2)

        // Largest connected piece of "bright".
        val label = IntArray(total)
        val queue = IntArray(total)
        var bestLabel = 0
        var bestSize = 0
        var next = 0
        for (start in 0 until total) {
            if (!grown[start] || label[start] != 0) continue
            next++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = next
            while (head < tail) {
                val p = queue[head++]
                val px = p % w
                val py = p / w
                if (px > 0 && grown[p - 1] && label[p - 1] == 0) { label[p - 1] = next; queue[tail++] = p - 1 }
                if (px < w - 1 && grown[p + 1] && label[p + 1] == 0) { label[p + 1] = next; queue[tail++] = p + 1 }
                if (py > 0 && grown[p - w] && label[p - w] == 0) { label[p - w] = next; queue[tail++] = p - w }
                if (py < h - 1 && grown[p + w] && label[p + w] == 0) { label[p + w] = next; queue[tail++] = p + w }
            }
            if (tail > bestSize) { bestSize = tail; bestLabel = next }
        }
        if (bestSize < 0.15f * total) return null

        // Corners: the page pixels that lie furthest into each corner direction.
        var tl = -1; var tr = -1; var br = -1; var bl = -1
        var vTl = Int.MAX_VALUE; var vTr = Int.MIN_VALUE; var vBr = Int.MIN_VALUE; var vBl = Int.MAX_VALUE
        for (p in 0 until total) {
            if (label[p] != bestLabel || !bright[p]) continue
            val x = p % w
            val y = p / w
            if (x + y < vTl) { vTl = x + y; tl = p }
            if (x - y > vTr) { vTr = x - y; tr = p }
            if (x + y > vBr) { vBr = x + y; br = p }
            if (x - y < vBl) { vBl = x - y; bl = p }
        }
        if (tl < 0 || tr < 0 || br < 0 || bl < 0) return null

        fun pt(p: Int) = Pt(((p % w) + 0.5f) / w, ((p / w) + 0.5f) / h)
        val quad = Quad(pt(tl), pt(tr), pt(br), pt(bl))
        return if (quad.area() >= 0.2f && quad.isConvex()) quad else null
    }

    private fun otsu(hist: IntArray, total: Int): Int {
        var sumAll = 0.0
        for (i in 0..255) sumAll += i.toDouble() * hist[i]
        var wB = 0
        var sumB = 0.0
        var best = 0.0
        var thr = 127
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sumB += t.toDouble() * hist[t]
            val mB = sumB / wB
            val mF = (sumAll - sumB) / wF
            val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; thr = t }
        }
        return thr
    }

    /** Spreads every true pixel by [radius] pixels in a square. */
    private fun dilate(src: BooleanArray, w: Int, h: Int, radius: Int): BooleanArray {
        // Separable: horizontal pass then vertical pass.
        val tmp = BooleanArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var on = false
                val x0 = max(0, x - radius)
                val x1 = min(w - 1, x + radius)
                for (xx in x0..x1) if (src[y * w + xx]) { on = true; break }
                tmp[y * w + x] = on
            }
        }
        val out = BooleanArray(w * h)
        for (y in 0 until h) {
            val y0 = max(0, y - radius)
            val y1 = min(h - 1, y + radius)
            for (x in 0 until w) {
                var on = false
                for (yy in y0..y1) if (tmp[yy * w + x]) { on = true; break }
                out[y * w + x] = on
            }
        }
        return out
    }
}
