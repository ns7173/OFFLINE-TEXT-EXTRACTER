package com.nitesh.offlineocr

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------------------------------
// Tables drawn with ruling lines (forms, challans, registers). The lines are found on the page
// image by InkMeasure.rules; the rows and columns come from those lines; the words go into the cells.
// Plain Kotlin, so it is tested on the JVM.
// ---------------------------------------------------------------------------------------

/**
 * One cell of a ruled grid. It covers grid rows r0 to r1 and grid columns c0 to c1 (inclusive), so
 * a cell that spans several rows or columns is one rectangle. The flags say which sides are ruled.
 */
data class GridRect(
    val r0: Int, val c0: Int, val r1: Int, val c1: Int,
    val top: Boolean, val left: Boolean, val bottom: Boolean, val right: Boolean,
    /** Text lines inside the cell, top to bottom. */
    val lines: List<String>,
    val align: Align,
    /** True when the text is printed up the page (a tall, narrow column). Written as bottom-to-top text. */
    val vertical: Boolean = false,
    /** Text of the cell is bold / underlined (most of its words are). */
    val bold: Boolean = false,
    val underline: Boolean = false,
)

/** A ruled table. Sizes are in page widths, like the other blocks. */
data class GridBlock(
    val rects: List<GridRect>,
    /** Height of each grid row. */
    val rowHeights: List<Float>,
    /** Width of each grid column. */
    val colWidths: List<Float>,
    /** Left edge; measured from the page's text margin once the layout places the block. */
    override val spaceBefore: Float,
    override val top: Float,
    val bottom: Float,
    val indentLeft: Float,
    val fontHeight: Float,
) : Block

object RuledGrid {
    /** Lines closer than this many pixels are the same line. */
    private const val LINE_TOL = 8

    /** A ruled side must cover this share of the cell side it belongs to. */
    private const val COVER = 0.8f

    /** Narrowest grid (share of the page width) that is treated as a table. */
    private const val MIN_GRID_WIDTH = 0.15f

    /** Narrowest column (share of the page width) that can hold text. */
    private const val MIN_COL = 0.02f

    /** At least this many distinct horizontal and vertical lines are needed for a grid. */
    private const val MIN_LINES = 3

    class Result(val block: GridBlock, val consumed: Set<OcrWord>)

    /** Two lines closer than this many pixels at their ends still count as joined. */
    private const val TOUCH = 10

    /**
     * All the grids on a page. The ruling lines are split into groups that join each other (a form
     * usually has several separate tables); each group that makes a grid gets its own [Result]. Words
     * already taken by an earlier grid are not offered to the next one.
     */
    fun buildAll(rules: List<Rule>, words: List<OcrWord>, pageW: Float, pageH: Float): List<Result> {
        val n = rules.size
        val parent = IntArray(n) { it }
        fun find(i: Int): Int {
            var x = i
            while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }
            return x
        }
        for (i in 0 until n) for (j in i + 1 until n) {
            if (joined(rules[i], rules[j])) parent[find(i)] = find(j)
        }
        val groups = (0 until n).groupBy { find(it) }.values.sortedBy { g -> g.minOf { rules[it].pos } }
        val out = ArrayList<Result>()
        var rest = words
        for (g in groups) {
            val sub = g.map { rules[it] }
            if (sub.count { it.horizontal } < 2 || sub.count { !it.horizontal } < 2) continue
            val res = build(sub, rest, pageW, pageH) ?: continue
            // One empty box is a picture on the form (an emblem, a stamp frame), not a table.
            if (res.block.rects.size == 1 && res.consumed.isEmpty()) continue
            // A form table is never a sliver: a box under a fifth of the page's width is a logo or a frame.
            if (res.block.colWidths.sum() < MIN_GRID_WIDTH) continue
            out += res
            rest = rest.filter { it !in res.consumed }
        }
        return out
    }

    /** True when two rules cross, or meet at an end, or run on the same line one after the other. */
    private fun joined(a: Rule, b: Rule): Boolean {
        if (a.horizontal == b.horizontal) {
            return abs(a.pos - b.pos) <= LINE_TOL && a.from <= b.to + TOUCH && b.from <= a.to + TOUCH
        }
        val h = if (a.horizontal) a else b
        val v = if (a.horizontal) b else a
        return v.pos in (h.from - TOUCH)..(h.to + TOUCH) && h.pos in (v.from - TOUCH)..(v.to + TOUCH)
    }

    /**
     * Builds the grid from [rules] (pixel coordinates of a [pageW] x [pageH] page). The grid runs from its
     * first to its last ruled horizontal line. Words whose centre lies in a ruled cell go into that cell
     * and are returned as [Result.consumed]; all other text stays in the normal flow. Null when the lines
     * do not make a grid.
     */
    fun build(rules: List<Rule>, words: List<OcrWord>, pageW: Float, pageH: Float): Result? {
        val hs = rules.filter { it.horizontal }
        val vs = rules.filter { !it.horizontal }
        if (hs.isEmpty() || vs.isEmpty()) return null
        // The grid also reaches the ends of the lines. Forms often leave the outer sides open (no drawn
        // edge), but the cells there still hold text; those edges get no border when they are drawn.
        val allYs = cluster(hs.map { it.pos.toFloat() } + vs.minOf { it.from }.toFloat() + vs.maxOf { it.to }.toFloat())
        // A column too narrow to hold text is a stroke of a letter, not a rule: its boundary is dropped.
        val xs = dropNarrow(cluster(vs.map { it.pos.toFloat() } + hs.minOf { it.from }.toFloat() + hs.maxOf { it.to }.toFloat()), MIN_COL * pageW)
        if (allYs.size < MIN_LINES || xs.size < MIN_LINES) return null

        // First pass over the whole box: which horizontal lines are really ruled around a cell?
        val firstPass = rectsFor(hs, vs, allYs, xs)
        val ruledLines = allYs.indices.filter { k ->
            firstPass.any { (it.top && it.r0 == k) || (it.bottom && it.r1 + 1 == k) }
        }
        if (ruledLines.size < 2) return null
        val first = ruledLines.first()
        val last = ruledLines.last()
        // Second pass: only between the first and the last ruled line.
        val ys = allYs.subList(first, last + 1)
        val rects = rectsFor(hs, vs, ys, xs)

        val nR = ys.size - 1
        val nC = xs.size - 1
        val left = xs.first(); val right = xs.last(); val top = ys.first(); val bottom = ys.last()

        // Words whose centre is in the grid go into the cell that holds that centre. Only cells with at
        // least one ruled side take words; text in an open area is left to the normal text flow.
        val rectAt = Array(nR) { arrayOfNulls<Int>(nC) }
        for ((idx, rc) in rects.withIndex()) for (r in rc.r0..rc.r1) for (c in rc.c0..rc.c1) rectAt[r][c] = idx
        val wordsOf = HashMap<Int, MutableList<OcrWord>>()
        val assigned = HashSet<OcrWord>()
        for (w in words) {
            val cx = (w.left + w.right) / 2f
            val cy = (w.top + w.bottom) / 2f
            if (cx < left || cx > right || cy < top || cy > bottom) continue
            val idx = rectAt[indexOfCell(ys, cy)][indexOfCell(xs, cx)] ?: continue
            val rc = rects[idx]
            if (!(rc.top || rc.left || rc.bottom || rc.right)) continue
            wordsOf.getOrPut(idx) { ArrayList() }.add(w)
            assigned += w
        }

        val finalRects = rects.mapIndexed { idx, rc ->
            val ws = wordsOf[idx].orEmpty()
            val cellL = xs[rc.c0]
            val cellR = xs[rc.c1 + 1]
            val vertical = isVerticalCell(ws)
            rc.copy(
                lines = when {
                    ws.isEmpty() -> emptyList()
                    vertical -> verticalLines(ws)
                    else -> OcrText.linesToText(ws).split('\n').filter { it.isNotBlank() }
                },
                align = alignOf(ws, cellL, cellR),
                vertical = vertical,
                bold = ws.isNotEmpty() && ws.count { it.bold } * 5 >= ws.size * 4,
                underline = ws.isNotEmpty() && ws.count { it.underline } * 5 >= ws.size * 4,
            )
        }

        val heights = (0 until nR).map { (ys[it + 1] - ys[it]) / pageW }
        val widths = (0 until nC).map { (xs[it + 1] - xs[it]) / pageW }
        // The smaller side of a word is its letter height (for a rotated word that is the width).
        val wordH = assigned.map { minOf(it.bottom - it.top, it.right - it.left) }.sorted()
        val fontH = if (wordH.isEmpty()) 0.02f else wordH[wordH.size / 2] / pageW

        val block = GridBlock(
            rects = finalRects,
            rowHeights = heights,
            colWidths = widths,
            spaceBefore = 0f,
            top = top / pageW,
            bottom = bottom / pageW,
            indentLeft = left / pageW,
            fontHeight = fontH,
        )
        return Result(block, assigned)
    }

    /**
     * The cells of the grid made by the horizontal lines [ys] and vertical lines [xs]. Neighbouring
     * cells with no line between them are merged, so a cell can span several rows or columns.
     */
    private fun rectsFor(hs: List<Rule>, vs: List<Rule>, ys: List<Float>, xs: List<Float>): List<GridRect> {
        fun hasH(yi: Int, x0: Float, x1: Float): Boolean {
            val need = COVER * (x1 - x0)
            return hs.any { abs(it.pos - ys[yi]) <= LINE_TOL && overlap(it.from.toFloat(), it.to.toFloat(), x0, x1) >= need }
        }
        fun hasV(xi: Int, y0: Float, y1: Float): Boolean {
            val need = COVER * (y1 - y0)
            return vs.any { abs(it.pos - xs[xi]) <= LINE_TOL && overlap(it.from.toFloat(), it.to.toFloat(), y0, y1) >= need }
        }

        val nR = ys.size - 1
        val nC = xs.size - 1
        val seen = Array(nR) { BooleanArray(nC) }
        val rects = ArrayList<GridRect>()
        for (i in 0 until nR) for (j in 0 until nC) {
            if (seen[i][j]) continue
            var c1 = j
            while (c1 + 1 < nC && !hasV(c1 + 1, ys[i], ys[i + 1]) && !seen[i][c1 + 1]) c1++
            var r1 = i
            while (r1 + 1 < nR && (j..c1).all { k -> !hasH(r1 + 1, xs[k], xs[k + 1]) && !seen[r1 + 1][k] }) r1++
            for (r in i..r1) for (c in j..c1) seen[r][c] = true
            rects += GridRect(
                r0 = i, c0 = j, r1 = r1, c1 = c1,
                top = hasH(i, xs[j], xs[c1 + 1]),
                left = hasV(j, ys[i], ys[r1 + 1]),
                bottom = hasH(r1 + 1, xs[j], xs[c1 + 1]),
                right = hasV(c1 + 1, ys[i], ys[r1 + 1]),
                lines = emptyList(),
                align = Align.LEFT,
            )
        }
        return rects
    }

    /**
     * Drops the inner boundaries that leave a column narrower than [min]. The outer edges are always kept
     * (the last one replaces its neighbour when the two are too close).
     */
    private fun dropNarrow(xs: List<Float>, min: Float): List<Float> {
        if (xs.size <= 2) return xs
        val out = arrayListOf(xs.first())
        for (k in 1 until xs.size - 1) if (xs[k] - out.last() >= min) out += xs[k]
        if (xs.last() - out.last() >= min || out.size == 1) out += xs.last() else out[out.size - 1] = xs.last()
        return out
    }

    /** Centres of the groups of lines that lie within LINE_TOL of each other, sorted. */
    private fun cluster(values: List<Float>): List<Float> {
        val sorted = values.sorted()
        val out = ArrayList<Float>()
        var group = ArrayList<Float>()
        for (v in sorted) {
            if (group.isNotEmpty() && v - group.last() > LINE_TOL) {
                out += group.average().toFloat()
                group = ArrayList()
            }
            group += v
        }
        if (group.isNotEmpty()) out += group.average().toFloat()
        return out
    }

    /** Index of the grid cell that holds [v]: the last line at or before it. */
    private fun indexOfCell(lines: List<Float>, v: Float): Int {
        var idx = 0
        for (i in 0 until lines.size - 1) if (v >= lines[i]) idx = i
        return min(idx, lines.size - 2)
    }

    /**
     * A cell whose text is printed up the page. A rotated word is a tall box, but short words (1-2 letters)
     * stay about square even when rotated, so a share of 40% tall words is enough, with at least two of them.
     */
    private fun isVerticalCell(ws: List<OcrWord>): Boolean {
        val tall = ws.count { it.bottom - it.top > it.right - it.left }
        return tall >= 2 && tall * 5 >= ws.size * 2
    }

    /**
     * Lines of a vertical cell. Each line is a column of words, left to right on the page; its words
     * read from the bottom up, as they are printed.
     */
    private fun verticalLines(ws: List<OcrWord>): List<String> {
        val widths = ws.map { it.right - it.left }.sorted()
        val tol = max(10f, widths[widths.size / 2] * 0.6f)
        fun centre(w: OcrWord) = (w.left + w.right) / 2f
        val groups = ArrayList<MutableList<OcrWord>>()
        for (w in ws.sortedBy { centre(it) }) {
            val last = groups.lastOrNull()
            if (last != null && centre(w) - centre(last.last()) <= tol) last += w else groups += arrayListOf(w)
        }
        return groups.map { g -> g.sortedByDescending { it.bottom }.joinToString(" ") { it.text } }
    }

    private fun overlap(a0: Float, a1: Float, b0: Float, b1: Float): Float =
        max(0f, min(a1, b1) - max(a0, b0))

    /** Alignment from the free space left and right of the words inside the cell. */
    private fun alignOf(ws: List<OcrWord>, cellL: Float, cellR: Float): Align {
        if (ws.isEmpty()) return Align.LEFT
        val cw = cellR - cellL
        if (cw <= 0f) return Align.LEFT
        val lg = (ws.minOf { it.left } - cellL) / cw
        val rg = (cellR - ws.maxOf { it.right }) / cw
        return when {
            lg > 0.2f && rg > 0.2f && abs(lg - rg) < 0.1f -> Align.CENTER
            lg > 0.2f && rg < 0.05f -> Align.RIGHT
            else -> Align.LEFT
        }
    }

    /**
     * Gray levels (0 = black, 255 = white) of ARGB pixels, for [InkMeasure]. Uses the usual luma weights.
     */
    fun grayFromArgb(argb: IntArray): IntArray = IntArray(argb.size) { i ->
        val c = argb[i]
        ((c shr 16 and 0xff) * 299 + (c shr 8 and 0xff) * 587 + (c and 0xff) * 114) / 1000
    }
}
