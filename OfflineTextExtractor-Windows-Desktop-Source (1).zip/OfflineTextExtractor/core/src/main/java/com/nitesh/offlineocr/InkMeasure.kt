package com.nitesh.offlineocr

import kotlin.math.max
import kotlin.math.min

/**
 * Measurements taken from the pixels of a scanned page: how thick the strokes of a word are (bold),
 * whether a line runs under it (underline), and where the long ruled lines of a table are.
 *
 * Pure Kotlin on an int array (0 = black, 255 = white), so it runs on the JVM for tests as well as on the phone.
 */
class GrayPage(val width: Int, val height: Int, val pixels: IntArray) {
    init {
        require(pixels.size == width * height) { "pixel count does not match size" }
    }
}

/** A pixel rectangle: [left, right) x [top, bottom). */
data class PixelBox(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width get() = right - left
    val height get() = bottom - top
}

/** A straight ruled line: horizontal (y fixed) or vertical (x fixed), from [from] to [to] along its axis. */
data class Rule(val horizontal: Boolean, val pos: Int, val from: Int, val to: Int, val thickness: Int)

object InkMeasure {
    /** Pixels darker than this are ink. Scans of old registers are greyer, so the caller can pass its own. */
    const val INK_LIMIT = 150

    /** A word is bold when its strokes are this many times thicker than the typical word on the page. */
    const val BOLD_RATIO = 1.45f

    /** Underline: one thin row of ink covering at least this share of the word's width, just below the glyphs. */
    const val UNDERLINE_COVER = 0.7f
    const val UNDERLINE_MAX_THICKNESS = 3
    /** An underline may run this many times the word's width at most (it is not a table rule). */
    const val UNDERLINE_RUN_SLACK = 1.3f

    /**
     * Median length of the horizontal ink runs inside [box]. Stems of thick letters make long runs; thin
     * strokes make short ones. Only runs shorter than the box are counted, so a rule through the word is ignored.
     */
    fun strokeWidth(page: GrayPage, box: PixelBox, limit: Int = INK_LIMIT): Float {
        val runs = ArrayList<Int>()
        for (y in max(0, box.top) until min(page.height, box.bottom)) {
            var run = 0
            for (x in max(0, box.left) until min(page.width, box.right)) {
                if (page.pixels[y * page.width + x] < limit) run++
                else {
                    if (run > 0) runs.add(run)
                    run = 0
                }
            }
            if (run > 0) runs.add(run)
        }
        if (runs.isEmpty()) return 0f
        val short = runs.filter { it < box.width }.ifEmpty { runs }.sorted()
        return short[short.size / 2].toFloat()
    }

    /** True when a thin row of ink lies just under [box] and covers most of its width. */
    fun hasUnderline(page: GrayPage, box: PixelBox, limit: Int = INK_LIMIT): Boolean {
        if (box.width < 12) return false
        val need = (UNDERLINE_COVER * box.width).toInt()
        val zoneTop = box.bottom - max(1, box.height / 8)
        val zoneBottom = min(page.height, box.bottom + max(4, box.height / 3))
        var y = zoneTop
        while (y < zoneBottom) {
            if (longestRun(page, y, box.left, box.right, limit) >= need && singleWordRun(page, y, box, limit)) {
                // Count how many rows in a row carry the line: a thin rule is 1-3 rows, a stroke of text is not.
                var rows = 0
                while (y + rows < page.height && rows <= UNDERLINE_MAX_THICKNESS &&
                    longestRun(page, y + rows, box.left, box.right, limit) >= need
                ) rows++
                if (rows in 1..UNDERLINE_MAX_THICKNESS) return true
                y += rows
            } else y++
        }
        return false
    }

    /**
     * Bold flag per word, relative to the page: the stroke width of each word is compared with the median
     * stroke width of all words on the page, so a scan that is only darker or lighter is still judged fairly.
     */
    fun styles(page: GrayPage, boxes: List<PixelBox>, limit: Int = INK_LIMIT): List<WordStyle> {
        val widths = boxes.map { strokeWidth(page, it, limit) }
        val pageMedian = widths.filter { it > 0f }.sorted().let { if (it.isEmpty()) 1f else it[it.size / 2] }
        return boxes.mapIndexed { i, b ->
            val w = widths[i]
            WordStyle(
                bold = w > 0f && w >= BOLD_RATIO * pageMedian,
                underline = hasUnderline(page, b, limit),
                strokeRatio = if (pageMedian > 0f) w / pageMedian else 0f,
            )
        }
    }

    data class WordStyle(val bold: Boolean, val underline: Boolean, val strokeRatio: Float)

    /**
     * Long straight dark lines: a horizontal rule is a run of ink at least [minLength] pixels long that
     * repeats on consecutive rows; a vertical one is the same down a column. Thickness is the row count.
     */
    fun rules(page: GrayPage, minLength: Int, limit: Int = INK_LIMIT): List<Rule> {
        val out = ArrayList<Rule>()
        out += scanLines(page, minLength, limit, horizontal = true)
        out += scanLines(page, minLength, limit, horizontal = false)
        return out
    }

    private fun scanLines(page: GrayPage, minLength: Int, limit: Int, horizontal: Boolean): List<Rule> {
        val lines = if (horizontal) page.height else page.width
        val len = if (horizontal) page.width else page.height
        // Open runs: key (start, end) -> first line index where it appeared.
        var open = HashMap<Long, Int>()
        val done = ArrayList<Rule>()
        fun key(a: Int, b: Int) = (a.toLong() shl 32) or b.toLong()
        for (li in 0..lines) {
            val cur = HashMap<Long, Int>()
            if (li < lines) {
                var start = -1
                for (p in 0..len) {
                    val ink = p < len && pixelAt(page, horizontal, li, p) < limit
                    if (ink && start < 0) start = p
                    if (!ink && start >= 0) {
                        if (p - start >= minLength) {
                            val k = key(start, p)
                            cur[k] = open[k] ?: li
                        }
                        start = -1
                    }
                }
            }
            // Runs that did not continue on this line end here.
            for ((k, first) in open) {
                if (!cur.containsKey(k)) {
                    val thick = li - first
                    if (thick in 1..UNDERLINE_MAX_THICKNESS + 2) {
                        done += Rule(horizontal, first + thick / 2, (k shr 32).toInt(), (k and 0xffffffffL).toInt(), thick)
                    }
                }
            }
            open = cur
        }
        return done
    }

    private fun pixelAt(page: GrayPage, horizontal: Boolean, line: Int, p: Int): Int =
        if (horizontal) page.pixels[line * page.width + p] else page.pixels[p * page.width + line]

    /**
     * A table rule runs far past one word; an underline ends about where its word ends. The ink run that
     * holds the word's centre must therefore stay within a little more than the word's width.
     */
    private fun singleWordRun(page: GrayPage, y: Int, box: PixelBox, limit: Int): Boolean {
        if (y < 0 || y >= page.height) return false
        val cx = (box.left + box.right) / 2
        if (page.pixels[y * page.width + cx] >= limit) return false
        var l = cx; while (l > 0 && page.pixels[y * page.width + l - 1] < limit) l--
        var r = cx; while (r < page.width - 1 && page.pixels[y * page.width + r + 1] < limit) r++
        val len = r - l + 1
        return len <= UNDERLINE_RUN_SLACK * box.width + 4
    }

    /** Longest unbroken stretch of ink in row [y] between [left] and [right]. A line is one stretch; text is many. */
    private fun longestRun(page: GrayPage, y: Int, left: Int, right: Int, limit: Int): Int {
        if (y < 0 || y >= page.height) return 0
        var best = 0; var run = 0
        for (x in max(0, left) until min(page.width, right)) {
            if (page.pixels[y * page.width + x] < limit) { run++; if (run > best) best = run } else run = 0
        }
        return best
    }

    private fun coverage(page: GrayPage, y: Int, left: Int, right: Int, limit: Int): Int {
        if (y < 0 || y >= page.height) return 0
        var n = 0
        for (x in max(0, left) until min(page.width, right)) if (page.pixels[y * page.width + x] < limit) n++
        return n
    }
}
