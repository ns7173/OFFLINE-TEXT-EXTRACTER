package com.nitesh.offlineocr

import java.io.OutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Writes a Word (.docx) file by hand, so no Office library is needed. Each scanned page becomes
 * one page of the document; paragraphs keep their alignment, indent and spacing, and tables
 * detected by [LayoutAnalyzer] become real Word tables.
 */
object DocxWriter {
    private const val PAGE_W = 11906 // A4, in twentieths of a point
    private const val PAGE_H = 16838
    /** Bottom page margin in twips (a quarter inch: page numbers sit low on scanned pages). */
    private const val BOTTOM = 360
    /** Page size of the document being written: A4 portrait, or A4 landscape when every scanned page is landscape. */
    private var pageW = PAGE_W
    private var pageH = PAGE_H

    private fun tw(v: Float) = (v * pageW).roundToInt()

    fun write(pages: List<PageModel>, out: OutputStream, borders: Boolean = true) {
        val zip = ZipBuilder(out)
        zip.add("[Content_Types].xml", CONTENT_TYPES)
        zip.add("_rels/.rels", ROOT_RELS)
        zip.add("word/_rels/document.xml.rels", DOC_RELS)
        zip.add("word/styles.xml", STYLES)
        zip.add("word/document.xml", document(pages, borders))
        zip.finish()
    }

    private fun document(pages: List<PageModel>, borders: Boolean): String {
        val filled = pages.filter { it.blocks.isNotEmpty() }
        val src = filled.ifEmpty { pages }

        // Landscape scans (Fee tables, wide registers) stay landscape. A mixed document stays portrait, because one
        // orientation for all pages is what Word can keep without a second section per page.
        val landscape = src.isNotEmpty() && src.all { it.aspect < 1f }
        pageW = if (landscape) PAGE_H else PAGE_W
        pageH = if (landscape) PAGE_W else PAGE_H
        val targetAspect = pageH.toFloat() / pageW

        // One set of margins for the whole document. Left/right use the smallest across pages
        // (the widest text area), so a sparse page can never make a full page re-wrap.
        val gLeft = src.minOfOrNull { it.marginLeft } ?: 0.1f
        val gRight = src.minOfOrNull { it.marginRight } ?: 0.1f
        val gTop = medianOf(src.map { it.marginTop }, 0.08f)

        // Font sizes are estimates; snap near-body sizes to the body size so text looks consistent.
        val sizes = filled.flatMap { p -> p.blocks.map { fontHp(it) } }.sorted()
        val bodyHp = if (sizes.isEmpty()) 22 else sizes[sizes.size / 2]
        // Photos make the same font measure 20-30% larger or smaller from one paragraph to the next, so anything
        // within that range of the body size becomes the body size. Real headings are well above it.
        fun snap(hp: Int) = if (hp >= 0.7f * bodyHp && hp <= 1.3f * bodyHp) bodyHp else hp

        val sb = StringBuilder(XML_HEAD)
        sb.append("<w:document xmlns:w=\"").append(W_NS).append("\"><w:body>")

        var started = false
        var lastWasTable = false
        for (page in filled) {
            val shift = page.marginLeft - gLeft
            // A photo taller than A4 (angle, extra background) would push the page onto a second sheet: bring
            // the vertical distances back to A4 proportions.
            var vk = min(1f, targetAspect / max(page.aspect, 0.1f))
            // If the page still would not fit on one sheet, tighten the gaps a little more (never below 70%).
            // 10% spare: the height estimate is rough, and a page number that falls just past the last line
            // would otherwise start a blank sheet of its own. A page with a ruled table gets 20%: its rows and
            // notes sit close to the bottom of a form, and the estimate runs short there.
            val usable = ((pageH - tw(gTop) - BOTTOM) * (if (page.blocks.any { it is GridBlock }) 0.8f else 0.9f)).toInt()
            var est = estimateHeight(page, vk) { snap(fontHp(it)) }
            // Dense pages (search reports with 300+ words) are tightened further; the floor keeps lines readable.
            // Grid rows grow with their text, so the estimate is re-measured after each step until it fits.
            var steps = 0
            while (est > usable && vk > 0.55f && steps++ < 40) {
                vk = max(0.55f, vk * usable.toFloat() / est * 0.98f)
                est = estimateHeight(page, vk) { snap(fontHp(it)) }
            }
            var firstOnPage = true
            for (b in page.blocks) {
                val pageBreak = started && firstOnPage
                when (b) {
                    is ParagraphBlock -> paragraph(sb, b, page.lineMult, shift, snap(fontHp(b)), pageBreak, vk)
                    is TableBlock -> table(sb, b, shift, snap(fontHp(b)), pageBreak, borders, vk)
                    is GridBlock -> grid(sb, b, shift, snap(fontHp(b)), pageBreak, vk)
                }
                lastWasTable = b is TableBlock || b is GridBlock
                firstOnPage = false
                started = true
            }
        }
        if (lastWasTable || !started) sb.append("<w:p/>") // Word needs a paragraph after a final table

        val orient = if (landscape) " w:orient=\"landscape\"" else ""
        sb.append("<w:sectPr><w:pgSz w:w=\"$pageW\" w:h=\"$pageH\"$orient/>")
        sb.append("<w:pgMar w:top=\"${tw(gTop)}\" w:right=\"${tw(gRight)}\" w:bottom=\"${BOTTOM}\" w:left=\"${tw(gLeft)}\"")
        sb.append(" w:header=\"360\" w:footer=\"360\" w:gutter=\"0\"/></w:sectPr>")
        sb.append("</w:body></w:document>")
        return sb.toString()
    }

    /** Rough height (twips) of one page's blocks at vertical scale [vk]; mirrors what [paragraph] and [table] write. */
    private fun estimateHeight(page: PageModel, vk: Float, hpOf: (Block) -> Int): Int {
        var total = 0
        for (b in page.blocks) {
            val hp = hpOf(b)
            total += tw(b.spaceBefore * vk)
            total += when (b) {
                is ParagraphBlock -> {
                    val line = if (b.linePitch > 0f) max(tw(b.linePitch * vk), (hp * 11.5f).roundToInt())
                    else (hp * 12f * page.lineMult).roundToInt()
                    line * b.lineCount
                }
                is TableBlock -> (hp * 13f).roundToInt() * b.rows.size
                is GridBlock -> gridRowHeights(b, vk, hp).sum()
            }
        }
        return total
    }

    private fun fontHp(b: Block): Int = when (b) {
        is ParagraphBlock -> fontHalfPoints(b.fontHeight)
        is TableBlock -> fontHalfPoints(b.fontHeight)
        is GridBlock -> fontHalfPoints(b.fontHeight)
    }

    /**
     * A ruled table as one Word table: rows keep the heights measured on the form, merged cells use
     * gridSpan / vMerge, and each cell gets only the borders the form has.
     */
    private fun grid(sb: StringBuilder, g: GridBlock, shift: Float, hp: Int, pageBreak: Boolean, vk: Float) {
        val gap = tw(g.spaceBefore * vk)
        if (pageBreak || gap > 40) {
            sb.append("<w:p><w:pPr>")
            if (pageBreak) sb.append("<w:pageBreakBefore/>")
            sb.append("<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"${max(20, gap)}\" w:lineRule=\"exact\"/>")
            sb.append("<w:rPr><w:sz w:val=\"2\"/></w:rPr></w:pPr></w:p>")
        }

        val widths = g.colWidths.map { tw(it) }
        val ind = tw(max(0f, g.indentLeft + shift))
        sb.append("<w:tbl><w:tblPr><w:tblW w:w=\"${widths.sum()}\" w:type=\"dxa\"/>")
        sb.append("<w:tblInd w:w=\"$ind\" w:type=\"dxa\"/>")
        sb.append("<w:tblLayout w:type=\"fixed\"/>")
        sb.append("<w:tblCellMar><w:left w:w=\"60\" w:type=\"dxa\"/><w:right w:w=\"60\" w:type=\"dxa\"/></w:tblCellMar>")
        sb.append("</w:tblPr><w:tblGrid>")
        widths.forEach { sb.append("<w:gridCol w:w=\"$it\"/>") }
        sb.append("</w:tblGrid>")

        val rowH = gridRowHeights(g, vk, hp)
        for (r in g.rowHeights.indices) {
            sb.append("<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val=\"${rowH[r]}\" w:hRule=\"atLeast\"/></w:trPr>")
            // Every cell that covers this row, left to right: the ones starting here, and the rest of tall cells.
            for (rc in g.rects.filter { r in it.r0..it.r1 }.sortedBy { it.c0 }) {
                val span = rc.c1 - rc.c0 + 1
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"${widths.subList(rc.c0, rc.c1 + 1).sum()}\" w:type=\"dxa\"/>")
                if (span > 1) sb.append("<w:gridSpan w:val=\"$span\"/>")
                if (rc.r1 > rc.r0) sb.append(if (r == rc.r0) "<w:vMerge w:val=\"restart\"/>" else "<w:vMerge/>")
                sb.append(cellBorders(rc, r))
                if (rc.vertical) sb.append("<w:textDirection w:val=\"btLr\"/>")
                sb.append("</w:tcPr>")
                val lines = if (r == rc.r0) rc.lines else emptyList()
                if (lines.isEmpty()) {
                    sb.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr></w:p>")
                } else {
                    val jc = when (rc.align) {
                        Align.CENTER -> "<w:jc w:val=\"center\"/>"
                        Align.RIGHT -> "<w:jc w:val=\"right\"/>"
                        else -> ""
                    }
                    for (line in lines) {
                        sb.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/>")
                        sb.append(jc).append("</w:pPr>")
                        runs(sb, line, hp, rc.bold, rc.underline)
                        sb.append("</w:p>")
                    }
                }
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
    }

    /**
     * Height of each grid row in twips: the measured height, or more when the row's text needs it. One line of
     * text takes about 1.2 times its font size (half-points x 12 gives twips).
     */
    private fun gridRowHeights(g: GridBlock, vk: Float, hp: Int): List<Int> {
        val need = IntArray(g.rowHeights.size)
        for (rc in g.rects) {
            if (rc.r1 != rc.r0 || rc.vertical || rc.lines.isEmpty()) continue
            need[rc.r0] = max(need[rc.r0], rc.lines.size * hp * 12)
        }
        return g.rowHeights.indices.map { r -> max(tw(g.rowHeights[r] * vk), need[r]) }
    }

    /** Borders of one cell in row [r]: the top and bottom only on the first and last row a tall cell covers. */
    private fun cellBorders(rc: GridRect, r: Int): String {
        fun side(name: String, on: Boolean) =
            if (on) "<w:$name w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"000000\"/>" else "<w:$name w:val=\"nil\"/>"
        return "<w:tcBorders>" +
            side("top", rc.top && r == rc.r0) +
            side("left", rc.left) +
            side("bottom", rc.bottom && r == rc.r1) +
            side("right", rc.right) +
            "</w:tcBorders>"
    }

    private fun paragraph(
        sb: StringBuilder, p: ParagraphBlock, lineMult: Float, shift: Float, hp: Int, pageBreak: Boolean, vk: Float,
    ) {
        sb.append("<w:p><w:pPr>")
        if (pageBreak) sb.append("<w:pageBreakBefore/>")
        if (p.tabs.isNotEmpty()) {
            sb.append("<w:tabs>")
            for (t in p.tabs) sb.append("<w:tab w:val=\"left\" w:pos=\"${tw(t + shift)}\"/>")
            sb.append("</w:tabs>")
        }
        // Lines of a multi-line paragraph keep the spacing measured on the scan, whatever font Word picks for
        // Devanagari (its line height varies a lot between fonts). Never tighter than the font itself.
        if (p.linePitch > 0f) {
            val exact = max(tw(p.linePitch * vk), (hp * 11.5f).roundToInt())
            sb.append("<w:spacing w:before=\"${tw(p.spaceBefore * vk)}\" w:after=\"0\" w:line=\"$exact\" w:lineRule=\"exact\"/>")
        } else {
            sb.append("<w:spacing w:before=\"${tw(p.spaceBefore * vk)}\" w:after=\"0\" w:line=\"${(240 * lineMult).roundToInt()}\" w:lineRule=\"auto\"/>")
        }

        val left = tw(max(0f, p.indentLeft + shift))
        val first = tw(p.firstLine)
        if (left != 0 || first != 0) {
            sb.append("<w:ind w:left=\"$left\"")
            if (first > 0) sb.append(" w:firstLine=\"$first\"")
            if (first < 0) sb.append(" w:hanging=\"${-first}\"")
            sb.append("/>")
        }
        val jc = when (p.align) {
            Align.LEFT -> null
            Align.CENTER -> "center"
            Align.RIGHT -> "right"
            Align.JUSTIFY -> "both"
        }
        if (jc != null) sb.append("<w:jc w:val=\"$jc\"/>")
        sb.append("</w:pPr>")
        runs(sb, p.text, hp, p.bold, p.underline)
        sb.append("</w:p>")
    }

    private fun table(sb: StringBuilder, t: TableBlock, shift: Float, hp: Int, pageBreak: Boolean, borders: Boolean, vk: Float) {
        // Word tables have no "space before", so a thin empty paragraph carries the gap / page break.
        val gap = tw(t.spaceBefore * vk)
        if (pageBreak || gap > 40) {
            sb.append("<w:p><w:pPr>")
            if (pageBreak) sb.append("<w:pageBreakBefore/>")
            sb.append("<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"${max(20, gap)}\" w:lineRule=\"exact\"/>")
            sb.append("<w:rPr><w:sz w:val=\"2\"/></w:rPr></w:pPr></w:p>")
        }

        val widths = t.colWidths.map { tw(it) }
        val ind = tw(max(0f, t.indentLeft + shift))
        sb.append("<w:tbl><w:tblPr><w:tblW w:w=\"${widths.sum()}\" w:type=\"dxa\"/>")
        sb.append("<w:tblInd w:w=\"$ind\" w:type=\"dxa\"/>")
        if (borders && t.bordered) sb.append(BORDERS)
        sb.append("<w:tblLayout w:type=\"fixed\"/>")
        sb.append("<w:tblCellMar><w:left w:w=\"60\" w:type=\"dxa\"/><w:right w:w=\"60\" w:type=\"dxa\"/></w:tblCellMar>")
        sb.append("</w:tblPr><w:tblGrid>")
        widths.forEach { sb.append("<w:gridCol w:w=\"$it\"/>") }
        sb.append("</w:tblGrid>")
        for (row in t.rows) {
            sb.append("<w:tr>")
            row.forEachIndexed { c, cell ->
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"${widths[c]}\" w:type=\"dxa\"/></w:tcPr>")
                sb.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/>")
                if (t.colAligns.getOrNull(c) == Align.RIGHT) sb.append("<w:jc w:val=\"right\"/>")
                sb.append("</w:pPr>")
                if (cell.isNotEmpty()) runs(sb, cell, hp)
                sb.append("</w:p></w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
    }

    /** One run; a TAB in [text] becomes a real Word tab. Font size is set for both Latin and complex (Devanagari) text. */
    private fun runs(sb: StringBuilder, text: String, hp: Int, bold: Boolean = false, underline: Boolean = false) {
        val props = (if (bold) "<w:b/><w:bCs/>" else "") + (if (underline) "<w:u w:val=\"single\"/>" else "")
        sb.append("<w:r><w:rPr>").append(props).append("<w:sz w:val=\"$hp\"/><w:szCs w:val=\"$hp\"/></w:rPr>")
        text.split('\t').forEachIndexed { i, part ->
            if (i > 0) sb.append("<w:tab/>")
            if (part.isNotEmpty()) sb.append("<w:t xml:space=\"preserve\">").append(xmlEscape(part)).append("</w:t>")
        }
        sb.append("</w:r>")
    }

    private fun medianOf(v: List<Float>, default: Float): Float {
        if (v.isEmpty()) return default
        val s = v.sorted()
        return s[s.size / 2]
    }

    // ----- static package parts ---------------------------------------------------------

    private const val W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    private const val BORDERS =
        "<w:tblBorders>" +
            "<w:top w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" +
            "<w:left w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" +
            "<w:bottom w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" +
            "<w:right w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" +
            "<w:insideH w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" +
            "<w:insideV w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" +
            "</w:tblBorders>"

    private const val CONTENT_TYPES = XML_HEAD +
        "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
        "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
        "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>" +
        "</Types>"

    private const val ROOT_RELS = XML_HEAD +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
        "</Relationships>"

    private const val DOC_RELS = XML_HEAD +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
        "</Relationships>"

    // Latin text uses Calibri; Devanagari (Hindi / Marathi) uses Mangal, which ships with Office.
    private const val STYLES = XML_HEAD +
        "<w:styles xmlns:w=\"$W_NS\">" +
        "<w:docDefaults>" +
        "<w:rPrDefault><w:rPr>" +
        "<w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:eastAsia=\"Calibri\" w:cs=\"Mangal\"/>" +
        "<w:sz w:val=\"22\"/><w:szCs w:val=\"22\"/>" +
        "<w:lang w:val=\"en-IN\" w:eastAsia=\"en-US\" w:bidi=\"hi-IN\"/>" +
        "</w:rPr></w:rPrDefault>" +
        "<w:pPrDefault><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault>" +
        "</w:docDefaults>" +
        "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>" +
        "</w:styles>"
}
