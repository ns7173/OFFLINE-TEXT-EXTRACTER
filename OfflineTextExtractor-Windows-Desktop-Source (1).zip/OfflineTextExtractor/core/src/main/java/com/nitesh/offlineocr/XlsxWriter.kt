package com.nitesh.offlineocr

import java.io.OutputStream
import kotlin.math.max

/**
 * Writes an Excel (.xlsx) file by hand. Each scanned page becomes one sheet. Detected tables
 * land in real cells (one column per table column, with borders and sensible widths); other
 * text goes one line per row. Plain numbers in tables are stored as numbers so they can be summed.
 */
object XlsxWriter {

    private val NUMBER = Regex("^-?(0|[1-9][0-9]{0,10})(\\.[0-9]+)?$")

    fun write(pages: List<PageModel>, out: OutputStream, borders: Boolean = true) {
        val sheets = pages.map { sheetXml(it, borders) }.ifEmpty { listOf(sheetXml(null, borders)) }

        val zip = ZipBuilder(out)
        zip.add("[Content_Types].xml", contentTypes(sheets.size))
        zip.add("_rels/.rels", ROOT_RELS)
        zip.add("xl/workbook.xml", workbook(sheets.size))
        zip.add("xl/_rels/workbook.xml.rels", workbookRels(sheets.size))
        zip.add("xl/styles.xml", STYLES)
        sheets.forEachIndexed { i, xml -> zip.add("xl/worksheets/sheet${i + 1}.xml", xml) }
        zip.finish()
    }

    private fun sheetXml(page: PageModel?, borders: Boolean): String {
        val rows = StringBuilder()
        val maxLen = ArrayList<Int>() // longest text per table column
        var r = 1
        var first = true

        for (b in page?.blocks.orEmpty()) {
            when (b) {
                is ParagraphBlock -> {
                    if (!first && b.spaceBefore > 0.5f * b.fontHeight) r++ // a blank row keeps visual gaps
                    rowXml(rows, r, b.text.split('\t'), style = 0, numbers = false)
                    r++
                }
                is TableBlock -> {
                    if (!first && b.spaceBefore > 0.5f * b.fontHeight) r++
                    for (cells in b.rows) {
                        rowXml(rows, r, cells, style = if (borders && b.bordered) 1 else 2, numbers = true)
                        cells.forEachIndexed { c, s ->
                            while (maxLen.size <= c) maxLen.add(0)
                            maxLen[c] = max(maxLen[c], s.length)
                        }
                        r++
                    }
                }
                is GridBlock -> {
                    // A ruled table: one sheet row per grid row; a merged cell's text sits in its first column.
                    if (!first && b.spaceBefore > 0.5f * b.fontHeight) r++
                    for (gr in b.rowHeights.indices) {
                        val cells = MutableList(b.colWidths.size) { "" }
                        for (rc in b.rects) if (rc.r0 == gr) cells[rc.c0] = rc.lines.joinToString(" ")
                        rowXml(rows, r, cells, style = 2, numbers = false)
                        cells.forEachIndexed { c, s ->
                            while (maxLen.size <= c) maxLen.add(0)
                            maxLen[c] = max(maxLen[c], s.length)
                        }
                        r++
                    }
                }
            }
            first = false
        }

        val sb = StringBuilder(XML_HEAD)
        sb.append("<worksheet xmlns=\"$MAIN_NS\">")
        if (maxLen.isNotEmpty()) {
            sb.append("<cols>")
            maxLen.forEachIndexed { c, len ->
                val width = (len * 1.2 + 2).coerceIn(8.0, 50.0)
                sb.append("<col min=\"${c + 1}\" max=\"${c + 1}\" width=\"$width\" customWidth=\"1\"/>")
            }
            sb.append("</cols>")
        }
        sb.append("<sheetData>").append(rows).append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun rowXml(sb: StringBuilder, r: Int, cells: List<String>, style: Int, numbers: Boolean) {
        if (cells.all { it.isEmpty() }) return
        sb.append("<row r=\"$r\">")
        cells.forEachIndexed { c, text ->
            if (text.isEmpty()) return@forEachIndexed
            val ref = colName(c) + r
            if (numbers && NUMBER.matches(text)) {
                sb.append("<c r=\"$ref\" s=\"$style\"><v>$text</v></c>")
            } else {
                sb.append("<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                    .append(xmlEscape(text)).append("</t></is></c>")
            }
        }
        sb.append("</row>")
    }

    /** 0 -> A, 25 -> Z, 26 -> AA ... */
    private fun colName(index: Int): String {
        var n = index
        val sb = StringBuilder()
        do {
            sb.insert(0, 'A' + n % 26)
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    // ----- static package parts ---------------------------------------------------------

    private const val MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    private fun contentTypes(n: Int): String {
        val sb = StringBuilder(XML_HEAD)
        sb.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
        sb.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
        sb.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        sb.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
        sb.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
        for (i in 1..n) {
            sb.append("<Override PartName=\"/xl/worksheets/sheet$i.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
        }
        sb.append("</Types>")
        return sb.toString()
    }

    private const val ROOT_RELS = XML_HEAD +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"$REL_NS/officeDocument\" Target=\"xl/workbook.xml\"/>" +
        "</Relationships>"

    private fun workbook(n: Int): String {
        val sb = StringBuilder(XML_HEAD)
        sb.append("<workbook xmlns=\"$MAIN_NS\" xmlns:r=\"$REL_NS\"><sheets>")
        for (i in 1..n) sb.append("<sheet name=\"Page $i\" sheetId=\"$i\" r:id=\"rId$i\"/>")
        sb.append("</sheets></workbook>")
        return sb.toString()
    }

    private fun workbookRels(n: Int): String {
        val sb = StringBuilder(XML_HEAD)
        sb.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        for (i in 1..n) {
            sb.append("<Relationship Id=\"rId$i\" Type=\"$REL_NS/worksheet\" Target=\"worksheets/sheet$i.xml\"/>")
        }
        sb.append("<Relationship Id=\"rId${n + 1}\" Type=\"$REL_NS/styles\" Target=\"styles.xml\"/>")
        sb.append("</Relationships>")
        return sb.toString()
    }

    private const val STYLES = XML_HEAD +
        "<styleSheet xmlns=\"$MAIN_NS\">" +
        "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
        "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
        "<borders count=\"2\">" +
        "<border><left/><right/><top/><bottom/><diagonal/></border>" +
        "<border>" +
        "<left style=\"thin\"><color rgb=\"FF999999\"/></left><right style=\"thin\"><color rgb=\"FF999999\"/></right>" +
        "<top style=\"thin\"><color rgb=\"FF999999\"/></top><bottom style=\"thin\"><color rgb=\"FF999999\"/></bottom>" +
        "<diagonal/></border>" +
        "</borders>" +
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"3\">" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\" applyAlignment=\"1\">" +
        "<alignment vertical=\"top\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\">" +
        "<alignment vertical=\"top\" wrapText=\"1\"/></xf>" +
        "</cellXfs>" +
        "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
        "</styleSheet>"
}
