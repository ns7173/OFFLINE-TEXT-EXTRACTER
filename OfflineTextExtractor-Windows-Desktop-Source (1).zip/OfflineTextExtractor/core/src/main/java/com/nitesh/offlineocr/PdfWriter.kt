package com.nitesh.offlineocr

import java.io.File
import java.io.OutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/** One page of a searchable PDF: the original picture (a JPEG file) and the words read from it, in its pixel frame. */
class PdfPageInput(val jpeg: File, val widthPx: Int, val heightPx: Int, val words: List<OcrWord>)

/**
 * Writes a "searchable PDF" by hand: each page shows the original scan unchanged, and the recognized
 * words sit on top of it as invisible text (render mode 3), so the page looks exactly like the scan
 * but can be searched and copied. No PDF library is needed. Plain Kotlin, no Android classes.
 *
 * The invisible text uses a font that is not embedded (nothing is ever drawn with it) and a ToUnicode
 * map, so Devanagari and Latin both come out as the right characters when searched or copied.
 */
object PdfWriter {
    private const val PAGE_W = 595f // A4 width in points

    private class Counting(val out: OutputStream) {
        var pos = 0L
        fun write(b: ByteArray) { out.write(b); pos += b.size }
        fun write(s: String) = write(s.toByteArray(Charsets.ISO_8859_1))
    }

    fun write(pages: List<PdfPageInput>, out: OutputStream) {
        // Every distinct character gets a 2-byte code (CID); the ToUnicode map turns codes back into text.
        val cidOf = LinkedHashMap<Int, Int>()
        cidOf[' '.code] = 1
        for (p in pages) for (w in p.words) w.text.codePoints().forEach { cp ->
            if (cp !in cidOf && cidOf.size < 65000) cidOf[cp] = cidOf.size + 1
        }

        val c = Counting(out)
        val offsets = ArrayList<Long>() // offsets[i] = position of object i+1
        fun begin(): Int { offsets.add(c.pos); return offsets.size }
        fun obj(body: String) { val n = begin(); c.write("$n 0 obj\n$body\nendobj\n") }
        fun stream(dict: String, data: ByteArray): Int {
            val n = begin()
            c.write("$n 0 obj\n<< $dict /Length ${data.size} >>\nstream\n")
            c.write(data)
            c.write("\nendstream\nendobj\n")
            return n
        }

        c.write("%PDF-1.5\n%âãÏÓ\n")
        // Fixed object numbers: 1 catalog, 2 page tree, 3 font, 4 CID font, 5 descriptor, 6 ToUnicode, then 3 per page.
        val kids = pages.indices.joinToString(" ") { "${7 + it * 3} 0 R" }
        obj("<< /Type /Catalog /Pages 2 0 R >>")
        obj("<< /Type /Pages /Kids [$kids] /Count ${pages.size} >>")
        obj("<< /Type /Font /Subtype /Type0 /BaseFont /GlyphlessText /Encoding /Identity-H /DescendantFonts [4 0 R] /ToUnicode 6 0 R >>")
        obj(
            "<< /Type /Font /Subtype /CIDFontType2 /BaseFont /GlyphlessText " +
                "/CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> " +
                "/FontDescriptor 5 0 R /DW 500 /W [1 [100]] /CIDToGIDMap /Identity >>"
        )
        obj(
            "<< /Type /FontDescriptor /FontName /GlyphlessText /Flags 4 /FontBBox [0 -200 1000 900] " +
                "/ItalicAngle 0 /Ascent 800 /Descent -200 /CapHeight 700 /StemV 80 >>"
        )
        stream("", toUnicodeCMap(cidOf).toByteArray(Charsets.ISO_8859_1))

        pages.forEachIndexed { i, p ->
            val scale = PAGE_W / max(1, p.widthPx)
            val pageH = p.heightPx * scale
            val pageObj = 7 + i * 3
            obj(
                "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(PAGE_W)} ${f(pageH)}] " +
                    "/Resources << /Font << /F1 3 0 R >> /XObject << /Im0 ${pageObj + 2} 0 R >> >> " +
                    "/Contents ${pageObj + 1} 0 R >>"
            )
            stream("", contentStream(p, scale, pageH, cidOf).toByteArray(Charsets.ISO_8859_1))
            stream(
                "/Type /XObject /Subtype /Image /Width ${p.widthPx} /Height ${p.heightPx} " +
                    "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode",
                p.jpeg.readBytes(),
            )
        }

        val xrefPos = c.pos
        c.write("xref\n0 ${offsets.size + 1}\n0000000000 65535 f \n")
        for (o in offsets) c.write(String.format(Locale.US, "%010d 00000 n \n", o))
        c.write("trailer\n<< /Size ${offsets.size + 1} /Root 1 0 R >>\nstartxref\n$xrefPos\n%%EOF\n")
        out.flush()
    }

    private fun f(v: Float) = String.format(Locale.US, "%.2f", v)

    private fun hex4(v: Int) = String.format("%04X", v)

    private fun contentStream(p: PdfPageInput, scale: Float, pageH: Float, cidOf: Map<Int, Int>): String {
        val sb = StringBuilder()
        sb.append("q ${f(PAGE_W)} 0 0 ${f(pageH)} 0 0 cm /Im0 Do Q\n")
        sb.append("BT 3 Tr\n")
        for (w in readingOrder(p.words)) {
            val cps = w.text.codePoints().toArray()
            if (cps.isEmpty()) continue
            val boxW = (w.right - w.left) * scale
            val boxH = (w.bottom - w.top) * scale
            if (boxW <= 0f || boxH <= 0f) continue
            val fs = max(1f, boxH * 0.85f)
            // Every code is 0.5 em wide (the space code only 0.1 em, so it fits in the gap between words);
            // stretch the run horizontally to cover the word's box.
            val tz = (100f * boxW / (cps.size * 0.5f * fs)).coerceIn(5f, 3000f)
            val x = w.left * scale
            val y = pageH - w.bottom * scale + 0.2f * boxH
            sb.append("/F1 ${f(fs)} Tf ${f(tz)} Tz 1 0 0 1 ${f(x)} ${f(y)} Tm <")
            for (cp in cps) sb.append(hex4(cidOf[cp] ?: 1))
            sb.append(hex4(1)) // a trailing space so copied text keeps words apart
            sb.append("> Tj\n")
        }
        sb.append("ET\n")
        return sb.toString()
    }

    /** Words in reading order: top to bottom by row, left to right inside a row. */
    internal fun readingOrder(words: List<OcrWord>): List<OcrWord> {
        val sorted = words.sortedBy { (it.top + it.bottom) / 2f }
        val rows = ArrayList<MutableList<OcrWord>>()
        var cy = 0f
        for (w in sorted) {
            val wcy = (w.top + w.bottom) / 2f
            val last = rows.lastOrNull()
            if (last != null && abs(wcy - cy) <= 0.6f * (w.bottom - w.top)) {
                last.add(w)
                cy = (cy * (last.size - 1) + wcy) / last.size
            } else {
                rows.add(mutableListOf(w))
                cy = wcy
            }
        }
        return rows.flatMap { r -> r.sortedBy { it.left } }
    }

    private fun toUnicodeCMap(cidOf: Map<Int, Int>): String {
        val sb = StringBuilder()
        sb.append("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n")
        sb.append("/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n")
        sb.append("/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n")
        sb.append("1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n")
        cidOf.entries.chunked(100).forEach { chunk ->
            sb.append("${chunk.size} beginbfchar\n")
            for ((cp, cid) in chunk) {
                sb.append('<').append(hex4(cid)).append("> <")
                String(Character.toChars(cp)).forEach { sb.append(hex4(it.code)) }
                sb.append(">\n")
            }
            sb.append("endbfchar\n")
        }
        sb.append("endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n")
        return sb.toString()
    }
}
