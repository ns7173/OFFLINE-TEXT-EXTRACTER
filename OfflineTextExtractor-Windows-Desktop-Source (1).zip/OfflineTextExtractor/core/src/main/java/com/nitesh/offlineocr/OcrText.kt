package com.nitesh.offlineocr

import kotlin.math.abs
import kotlin.math.max

// ---------------------------------------------------------------------------------------
// Small helpers on recognized text. Plain Kotlin, unit-testable on a normal JVM.
// ---------------------------------------------------------------------------------------

object OcrText {

    /**
     * Bengali digits never appear in Hindi, Marathi or English legal text, so when ML Kit returns one
     * it is a misread of a Latin digit. The Bengali ৪ (U+09EA) is the one that is misread most: in a
     * Raipur sale deed it stood for an 8 in every case ("৪9457" = 89457, "৪0222" = 80222), so it maps
     * to 8. The other Bengali digits map to the digit of the same value.
     */
    fun normalizeDigits(s: String): String {
        if (s.none { it in '০'..'৯' }) return s
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when (c) {
                    '৪' -> '8'
                    in '০'..'৯' -> '0' + (c - '০')
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    /**
     * Plain text for words that came from a PDF text layer: words on the same line are joined with
     * spaces, and lines are separated by a newline. Words are grouped by how far apart their centres are.
     */
    fun linesToText(words: List<OcrWord>): String {
        if (words.isEmpty()) return ""
        val sorted = words.sortedBy { (it.top + it.bottom) / 2f }
        val lines = ArrayList<MutableList<OcrWord>>()
        for (w in sorted) {
            val cy = (w.top + w.bottom) / 2f
            val current = lines.lastOrNull()
            val currentY = current?.let { line -> line.sumOf { ((it.top + it.bottom) / 2f).toDouble() } / line.size }
            val h = max(1f, w.bottom - w.top)
            if (current != null && currentY != null && abs(cy - currentY.toFloat()) < h * 0.5f) current.add(w)
            else lines.add(mutableListOf(w))
        }
        return lines.joinToString("\n") { line ->
            line.sortedBy { it.left }.joinToString(" ") { it.text }
        }
    }

    /** Keeps the words whose centre lies inside [left, right) x [top, bottom). */
    fun wordsInside(words: List<OcrWord>, left: Int, top: Int, right: Int, bottom: Int): List<OcrWord> =
        words.filter { w ->
            val cx = (w.left + w.right) / 2f
            val cy = (w.top + w.bottom) / 2f
            cx >= left && cx < right && cy >= top && cy < bottom
        }
}
