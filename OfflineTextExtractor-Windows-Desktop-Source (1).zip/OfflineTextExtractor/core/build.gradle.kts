// Shared engine: layout, Word/Excel/PDF writers, saved-scan format and ruled-table detection.
// Pure Kotlin/JVM, no Android APIs, so the same code runs in the phone app and the Windows desktop app.
plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "17"
}
