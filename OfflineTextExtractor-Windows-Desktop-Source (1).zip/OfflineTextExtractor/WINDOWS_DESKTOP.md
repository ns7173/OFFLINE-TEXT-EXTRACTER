# Windows desktop version

This project now includes a separate Windows-capable desktop app in `desktop/`. It reuses the existing source repository but does not try to run Android UI or Android ML Kit on Windows.

## Current desktop features

- Choose a PNG, JPEG, TIFF, BMP, or WebP image.
- Extract printed text locally with Tesseract OCR.
- Select Hindi + English (`hin+eng`) or English (`eng`).
- Edit extracted text and save it as UTF-8 `.txt`.

This is a first desktop edition; it does not yet include the Android app's scan preview, multi-image/PDF workflows, or Word/Excel exports.

## OCR prerequisite

Install Tesseract OCR for Windows and make sure `tesseract.exe` is available on the Windows `PATH`. Install the English and Hindi trained-data files if those languages are needed. The application checks the local Tesseract command and does not upload images or text.

## Build a Windows installer EXE

The installer must be produced on Windows. The repository includes `.github/workflows/windows-exe.yml`:

1. Put this project in a GitHub repository.
2. Open **Actions** and run **Build Windows EXE** (or push a change to `desktop/` / `core/`).
3. Download the `OfflineTextExtractor-Windows-Installer` artifact from the completed run.
4. Install and launch the app. Tesseract OCR remains a separate prerequisite and must be installed on the target PC.

The Windows workflow installs a JDK and WiX Toolset, then runs `:desktop:packageWindowsExe` with `jpackage`. On any platform with a JDK, the desktop code can also be compiled with `./gradlew :desktop:build`; run it locally using `./gradlew :desktop:run`.
