# Offline Text Extractor (native Android)

Extracts text from photos, camera shots and PDFs, fully on the phone. Works in airplane mode.

## What it does
- **Screen layout.** On a phone the text box takes all the free space. Camera / Photos / PDF and the language chips sit above it. Below it: **Copy**, **Share**, **Save ▾** (text, Word, Excel, searchable PDF, scan data) and **More ▾** (preview, open a saved scan, clear). The Word/Excel switches (Auto, Tables, Borders, Keep line breaks) are under **Options**. On a wide screen (tablet, Chromebook, desktop window, 720 dp or more) the controls are in a left panel and the text box fills the right side.
- **Camera / Photos / PDF** input. Photos supports up to 20 images in one batch; PDFs are read page by page (scanned or digital).
- **Preview before reading.** Picking a file opens a preview screen (like most scanner apps):
  - **Rotate ↻** turns the page 90° at a time (per page; "More > Rotate all pages" for the whole file).
  - **Select areas:** drag on the page to draw numbered boxes. They are read in numbered order, so you can pick a paragraph, a table, or just the parts you need. No box drawn means the whole page is read.
  - **Columns:** one tap splits the page into 2 or 3 columns (read left to right). Undo removes the last box, Clear removes all boxes on the page.
  - **Pages:** flip through pages with the arrows, then read **All pages**, **This page**, or a range such as `1-3, 5`. "More > Copy these areas to all pages" reuses one selection for every page.
  - After reading, "Preview / change pages and areas" reopens the same file with your selection kept.
- **Fix tilted and angled photos** (per page, in the preview screen):
  - **Crop / flatten:** drag four corner handles onto the page corners (or tap **Auto crop**) and the page is flattened into a straight rectangle. This corrects a phone held at an angle, so the page looks like a trapezoid. Auto crop expects a light page on a darker background; if it can't find the page, drag the corners by hand.
  - **Straighten:** measures how much the text lines are tilted and turns the page to level them (**Auto straighten**), with a ±15° slider and red guide lines for fine control.
  - Order of operations is rotate by 90°, then flatten, then straighten, and the same steps are applied at full resolution before reading. Areas you drew on a page are cleared if you change its crop or tilt afterwards, because they would no longer line up.
- **Languages:** Hindi, Marathi, Sanskrit and English (Devanagari + Latin recognizer), or English only.
- **Edit, Copy, Share, Save .txt** on the result. Multi-page results get a heading per page.
- **Save as Word (.docx) and Excel (.xlsx), keeping the layout.** The scan's word positions are turned back into:
  - paragraphs (lines of one paragraph are re-joined, so the text reflows in Word),
  - alignment (left, centered, right, justified), indents, first-line and hanging indents,
  - spacing between paragraphs, estimated font sizes, and one page per scanned page,
  - real tables (Word tables with borders; Excel cells, one column per table column, numbers stored as numbers).
  Excel gets one sheet per page. Both files are written by the app itself, offline.
- **Searchable PDF** ("Save as searchable PDF"): each page shows the scan exactly as it looks (after your crop, flatten and straighten), with the recognized text invisibly on top, so it can be searched and copied. Stamps, signatures, ruled lines and images are all kept because the picture itself is kept. Only the areas you chose are searchable if you drew areas. It needs the page pictures, so it is available right after a scan, not after "Open a saved scan". Pages are stored as JPEG, so the file is larger than a plain text export.
- **Auto** (on by default; **Export options** under the text box): checks each detected table. A real data table (several filled rows, or numbers) gets borders; a block that only lines text up in columns (a two-line signature block, "Appellant / Respondent" labels, two columns of running text) keeps its column positions but gets no borders. Turn Auto off to border every table. Auto uses simple rules, not learning, so check unusual forms.
- **Tuned on a real court document** (a photographed Hindi *jawabdawa*): numbered paragraphs ("1.", "2.", also "3" when the dot was missed) become hanging numbered paragraphs with the text tabbed in, headings and "बनाम" are centred, a page number at the right stays at the right, "label ........ label" lines keep their right label with a tab stop, party/date blocks become borderless aligned tables, and line spacing is locked to what the scan measured so the page stays one sheet. Font sizes within about 30% of the body size are made equal, because photos make the same font measure larger or smaller down the page. The font factor (`FONT_FROM_HEIGHT`) is now 0.8.
- **Also tuned on a 5-page scanned sale deed:** a label on the left with details on the right ("प्रथम पक्षकार | name, father, caste, address, PAN ...") becomes one borderless table with the detail lines kept in the right column; form-style blocks and witness blocks get no lines; short-cell grids (the four sides of a plot) and tables with numbers in two or more columns (serial, date, amount) get lines; amounts are right-aligned in their column; page numbers stay at the right.
- **Export options** (shown under the text box after a scan): **Tables** on/off (off keeps aligned pieces in a line separated by tabs), **Borders** on/off for tables, and **Keep line breaks** (every scanned line stays its own paragraph instead of being re-joined).
- **Save scan data (.json) / Open a saved scan:** saves the text and every word's position, so Word/Excel can be exported again later (with different options) without scanning. It also lets you send a scan to someone to improve the layout rules. The file contains the document's text, so treat it as confidential.
- **No network code.** The ML Kit recognition models are bundled inside the APK, so nothing is downloaded at runtime.

## Build the APK
1. Install **Android Studio** (a recent version; it bundles JDK 17).
2. `File > Open` and choose this `OfflineTextExtractor` folder. Let Gradle sync (needs internet once, to fetch libraries).
3. Connect a phone with USB debugging on, or start an emulator, then press **Run**.
4. To get a shareable file: `Build > Build Bundle(s) / APK(s) > Build APK(s)`. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk` and installs fine on your own phones.

Or from a terminal, with Android Studio's SDK installed: `./gradlew assembleDebug`

## Test that it really works offline
Turn on airplane mode, open the app, and scan a Hindi page. If text comes out, you are good. Do this on a real phone before relying on it.

## Known limits
- Best on clear **printed** text. Handwriting, faded stamps and heavily skewed photos give poor results.
- Layout is rebuilt from word positions, so it is an approximation, not a pixel copy:
  - Word, Excel and PDF export use the scan, **not edits** made in the text box (the app says so when you have edited).
  - Bold, italics, colours, images, stamps and ruled lines are not kept. Tables are detected from aligned columns; a table with no clear gaps between columns may come out as plain paragraphs, and form-like blocks such as signature lines become borderless aligned tables when Auto is on (bordered when it is off).
  - Font sizes are estimated from line height (`FONT_FROM_HEIGHT` in `Layout.kt`; tune it if text comes out consistently too big or small). Latin uses Calibri, Hindi/Marathi uses Mangal.
  - Tilted photos hurt row detection. Photograph the page flat and fill the frame, which also makes font sizes more accurate. Use **Crop / flatten** and **Straighten** in the preview before reading: a photo taken at an angle makes the page look taller than A4, and the export then has to squeeze the vertical spacing to fit.
- Boxes cannot be moved or resized once drawn (use Undo and redraw), and the preview has no pinch-zoom yet.
- Flattening corrects a flat page photographed at an angle. It cannot flatten a curved or bent page (for example near a book spine), and uneven shadows are not corrected. Auto crop and Auto straighten are best-effort; check the result and adjust by hand if needed.
- With drawn areas, Word/Excel export stacks the areas in order from the page margin (a right-hand column follows the left one) rather than keeping their position on the page.
- ML Kit may merge an INTERNET permission for its own usage logging. The manifest has a commented line to strip it if you want to block that completely; test again if you enable it.

## How the export works
`OcrEngine` returns every word with its box (`OcrPage`). `Layout.kt` (`LayoutAnalyzer`) groups words into rows, splits rows at wide gaps, detects tables and paragraphs, and produces a `PageModel`. `DocxWriter` and `XlsxWriter` turn that model into Office files. These three files use no Android classes, so they can be tested on a plain JVM.

## Where to extend it
- `OcrEngine.kt`: the recognizer wrapper. Add pre-processing (contrast, deskew) before `recognize`.
- `OcrViewModel.kt`: the scan pipeline. Add a rule-based parser here to pull out fields such as names, khasra numbers, dates and areas.
- Optional online step: when internet is available, send the extracted text to an AI model for cleanup or structured output.
