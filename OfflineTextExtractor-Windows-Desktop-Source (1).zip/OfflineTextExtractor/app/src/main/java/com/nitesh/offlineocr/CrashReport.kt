package com.nitesh.offlineocr

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Saves the stack trace of an unexpected crash to a file, so the next time the app
 * opens it can be shown (and copied) on the phone itself. No laptop or Logcat needed.
 */
object CrashReport {
    private const val FILE_NAME = "last_crash.txt"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val trace = StringWriter()
                error.printStackTrace(PrintWriter(trace))
                val header = buildString {
                    append("Time: ")
                    append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
                    append('\n')
                    append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                    append(" | Android ").append(Build.VERSION.RELEASE)
                    append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n")
                    append("Thread: ").append(thread.name).append("\n\n")
                }
                File(app.filesDir, FILE_NAME).writeText(header + trace.toString())
            } catch (e: Throwable) {
                // Never let the logger itself hide the original crash.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun read(context: Context): String? = try {
        File(context.applicationContext.filesDir, FILE_NAME)
            .takeIf { it.exists() }
            ?.readText()
    } catch (e: Throwable) {
        null
    }

    fun clear(context: Context) {
        try {
            File(context.applicationContext.filesDir, FILE_NAME).delete()
        } catch (e: Throwable) {
            // Ignore: the report will just show again next time.
        }
    }
}

/** Application entry point: installs the crash logger before any screen is created. */
class OcrApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashReport.install(this)
    }
}
