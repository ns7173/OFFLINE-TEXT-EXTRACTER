package com.nitesh.offlineocr

import kotlin.math.roundToInt

// Pure Kotlin (no Android classes) so it can be unit-tested on a normal JVM.

/** A rectangle on a page, as fractions (0..1) of the page's width and height. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    /** The same rectangle after the page is turned 90 degrees clockwise. */
    fun rotatedCw(): NormRect = NormRect(1f - bottom, left, 1f - top, right)
}

data class PixelRect(val x: Int, val y: Int, val w: Int, val h: Int)

/** Converts to a pixel crop of a [width] x [height] bitmap; null if the area is too small to read. */
fun NormRect.toPixels(width: Int, height: Int): PixelRect? {
    val x0 = (left * width).toInt().coerceIn(0, width - 1)
    val y0 = (top * height).toInt().coerceIn(0, height - 1)
    val x1 = (right * width).roundToInt().coerceIn(x0 + 1, width)
    val y1 = (bottom * height).roundToInt().coerceIn(y0 + 1, height)
    val w = x1 - x0
    val h = y1 - y0
    return if (w < 8 || h < 8) null else PixelRect(x0, y0, w, h)
}

/** [count] equal full-height columns, left to right. */
fun columnRects(count: Int): List<NormRect> =
    List(count) { NormRect(it / count.toFloat(), 0f, (it + 1) / count.toFloat(), 1f) }

/**
 * Parses "2-5, 8" into zero-based page indexes [1, 2, 3, 4, 7]. Returns null if the text is
 * empty, malformed, or names a page outside 1..[pageCount].
 */
fun parsePageRange(text: String, pageCount: Int): List<Int>? {
    val parts = text.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
    if (parts.isEmpty()) return null
    val out = sortedSetOf<Int>()
    for (part in parts) {
        val ends = part.split('-').map { it.trim() }
        val a = ends[0].toIntOrNull() ?: return null
        val b = when (ends.size) {
            1 -> a
            2 -> ends[1].toIntOrNull() ?: return null
            else -> return null
        }
        if (a < 1 || b < a || b > pageCount) return null
        for (p in a..b) out.add(p - 1)
    }
    return out.toList()
}

/** Moves a word by a pixel offset (used to put a cropped area back into full-page coordinates). */
fun OcrWord.shifted(dx: Float, dy: Float) = OcrWord(text, left + dx, top + dy, right + dx, bottom + dy)
