package com.nitesh.offlineocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

/** Longest side, in pixels, that we hand to OCR. Keeps memory bounded on low-end phones. */
const val OCR_MAX_DIM = 3000

/** Longest side of the preview shown on screen. */
const val PREVIEW_MAX_DIM = 1600

/** Turns a bitmap clockwise by a multiple of 90 degrees. Returns this same bitmap for 0. */
fun Bitmap.rotated(degrees: Int): Bitmap {
    val d = ((degrees % 360) + 360) % 360
    if (d == 0) return this
    val matrix = Matrix().apply { postRotate(d.toFloat()) }
    return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
}

object BitmapLoader {

    /** Decodes an image from a content Uri, scaled so its longest side is at most [maxDim], and upright using EXIF. */
    suspend fun loadImage(context: Context, uri: Uri, maxDim: Int = OCR_MAX_DIM): Bitmap? =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null

            // Largest power-of-two sample that still leaves the image at least maxDim wide, then scale down exactly.
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2

            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: return@withContext null

            val longest = max(decoded.width, decoded.height)
            val sized = if (longest > maxDim) {
                val f = maxDim.toFloat() / longest
                val scaled = Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * f).roundToInt().coerceAtLeast(1),
                    (decoded.height * f).roundToInt().coerceAtLeast(1),
                    true,
                )
                if (scaled !== decoded) decoded.recycle()
                scaled
            } else {
                decoded
            }

            val degrees = runCatching {
                resolver.openInputStream(uri)?.use { stream ->
                    when (ExifInterface(stream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                } ?: 0
            }.getOrDefault(0)

            val upright = sized.rotated(degrees)
            if (upright !== sized) sized.recycle()
            upright
        }
}

/** A PDF opened with the platform PdfRenderer. Pages are rendered one at a time. */
class PdfDoc private constructor(
    private val descriptor: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) : Closeable {

    // PdfRenderer allows only one open page at a time, so renders and close are serialized.
    private val lock = Any()
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, maxDim: Int = OCR_MAX_DIM): Bitmap = withContext(Dispatchers.IO) {
        synchronized(lock) {
            renderer.openPage(index).use { page ->
                val scale = maxDim.toFloat() / max(page.width, page.height)
                val width = (page.width * scale).toInt().coerceAtLeast(1)
                val height = (page.height * scale).toInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.WHITE) // PdfRenderer draws on transparent; OCR wants white
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmap
            }
        }
    }

    override fun close() {
        synchronized(lock) {
            runCatching { renderer.close() }
            runCatching { descriptor.close() }
        }
    }

    companion object {
        suspend fun open(context: Context, uri: Uri): PdfDoc = withContext(Dispatchers.IO) {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: throw IOException("Could not open the PDF")
            try {
                PdfDoc(pfd, PdfRenderer(pfd))
            } catch (e: Exception) {
                pfd.close()
                throw IOException("This PDF could not be read (it may be password-protected or damaged)", e)
            }
        }
    }
}

/** The pages of whatever the user picked: a list of images, or the pages of one PDF. */
class PageSource private constructor(
    private val context: Context,
    private val uris: List<Uri>,
    private val pdf: PdfDoc?,
    private val textLayer: PdfTextLayer?,
) : Closeable {

    val isPdf: Boolean get() = pdf != null
    val pageCount: Int get() = pdf?.pageCount ?: uris.size

    /** Loads page [index] upright, scaled to at most [maxDim] on its longest side. */
    suspend fun load(index: Int, maxDim: Int): Bitmap? =
        if (pdf != null) pdf.render(index, maxDim) else BitmapLoader.loadImage(context, uris[index], maxDim)

    /** Words already stored in the PDF page, scaled to [width] x [height]; null when the page must be OCR'd. */
    suspend fun embeddedWords(index: Int, width: Int, height: Int): OcrPage? =
        withContext(Dispatchers.IO) { textLayer?.wordsFor(index, width, height) }

    override fun close() {
        pdf?.close()
        textLayer?.close()
    }

    companion object {
        fun images(context: Context, uris: List<Uri>) = PageSource(context.applicationContext, uris, null, null)

        suspend fun pdf(context: Context, uri: Uri) = withContext(Dispatchers.IO) {
            PageSource(
                context.applicationContext,
                emptyList(),
                PdfDoc.open(context, uri),
                PdfTextLayer.open(context, uri),
            )
        }
    }
}
