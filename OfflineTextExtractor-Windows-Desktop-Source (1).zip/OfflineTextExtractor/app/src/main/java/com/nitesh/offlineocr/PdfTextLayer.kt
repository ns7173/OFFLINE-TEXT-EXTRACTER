package com.nitesh.offlineocr

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.Closeable
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Reads the text that is already inside a PDF (Word, Writer and most computer-made PDFs).
 * That text is exact, so it is used instead of OCR whenever a page has it. Scanned pages have
 * no such text and fall back to OCR.
 *
 * Word boxes are returned in pixels of the page as it was rendered for OCR, so they line up with
 * the bitmap that the layout code already uses.
 */
class PdfTextLayer private constructor(private val doc: PDDocument) : Closeable {

    // PDFBox documents are not safe for concurrent use.
    private val lock = Any()

    /**
     * Words of page [index] scaled to a [bitmapWidth] x [bitmapHeight] image of that page.
     * Null when the page has too little text (a scan), or the page is rotated, which this reader
     * does not handle yet. Callers then use OCR instead.
     */
    fun wordsFor(index: Int, bitmapWidth: Int, bitmapHeight: Int): OcrPage? = synchronized(lock) {
        runCatching {
            if (index !in 0 until doc.numberOfPages) return@runCatching null
            val page = doc.getPage(index)
            if (page.rotation != 0) return@runCatching null
            val box = page.cropBox
            val pageW = box.width
            val pageH = box.height
            if (pageW <= 0f || pageH <= 0f) return@runCatching null

            val glyphs = ArrayList<TextPosition>()
            val stripper = object : PDFTextStripper() {
                override fun processTextPosition(text: TextPosition) {
                    glyphs.add(text)
                }
            }
            stripper.setStartPage(index + 1)
            stripper.setEndPage(index + 1)
            stripper.getText(doc)

            // Legacy Hindi fonts (Kruti Dev, DevLys, Chanakya, ...) store Latin letters in the text layer,
            // so the stored text is not Hindi. Such pages are read by OCR, which sees the printed glyphs.
            if (glyphs.any { LEGACY_FONT.containsMatchIn(it.font?.name ?: "") }) return@runCatching null

            val words = groupGlyphs(
                glyphs,
                originX = box.lowerLeftX,
                scaleX = bitmapWidth / pageW,
                scaleY = bitmapHeight / pageH,
            )
            if (words.size < MIN_WORDS_PER_PAGE) null else OcrPage(bitmapWidth, bitmapHeight, words)
        }.getOrNull()
    }

    override fun close() {
        synchronized(lock) { runCatching { doc.close() } }
    }

    companion object {
        /** Fewer words than this on a page and we treat the page as a scan. */
        const val MIN_WORDS_PER_PAGE = 3

        /** Font names of the legacy (non-Unicode) Hindi fonts. Matched against the name inside the PDF. */
        internal val LEGACY_FONT = Regex(
            "kruti|devlys|dev ?lys|chanakya|shusha|walkman|apsrlipi|dv-?ttsurekh",
            RegexOption.IGNORE_CASE,
        )

        private var resourcesReady = false

        /** Opens the PDF's text layer, or returns null when the file cannot be read this way. */
        fun open(context: Context, uri: Uri): PdfTextLayer? = runCatching {
            synchronized(this) {
                if (!resourcesReady) {
                    PDFBoxResourceLoader.init(context.applicationContext)
                    resourcesReady = true
                }
            }
            val doc = context.contentResolver.openInputStream(uri)?.use { PDDocument.load(it) }
                ?: return@runCatching null
            PdfTextLayer(doc)
        }.getOrNull()

        /**
         * Joins glyphs into words and converts them to pixels. A new word starts at a line change, or
         * at a gap wider than a fifth of the font size. A space is usually not a glyph in these PDFs,
         * so the gap is what separates words (a space is about a quarter of the font size).
         */
        internal fun groupGlyphs(
            glyphs: List<TextPosition>,
            originX: Float,
            scaleX: Float,
            scaleY: Float,
        ): List<OcrWord> {
            val words = ArrayList<OcrWord>()
            val sb = StringBuilder()
            var left = 0f; var top = 0f; var right = 0f; var bottom = 0f
            var lastRight = 0f; var lastBaseline = 0f; var lastH = 0f
            var open = false

            fun flush() {
                if (open && sb.isNotBlank()) {
                    words.add(OcrWord(OcrText.normalizeDigits(sb.toString()), left, top, right, bottom))
                }
                sb.setLength(0)
                open = false
            }

            for (g in glyphs) {
                val text = g.unicode ?: ""
                if (text.isBlank()) { flush(); continue }

                val x = (g.xDirAdj - originX) * scaleX
                val baseline = g.yDirAdj * scaleY
                // The font size gives a steady line height; the glyph bounding box varies by font.
                val h = max(1f, g.fontSizeInPt * scaleY)
                val w = max(0f, g.widthDirAdj * scaleX)
                val gTop = baseline - h * 0.8f
                val gBottom = baseline + h * 0.2f

                if (open) {
                    val sameLine = abs(baseline - lastBaseline) < lastH * 0.5f
                    val gap = x - lastRight
                    if (!sameLine || gap > lastH * 0.2f) flush()
                }

                if (!open) {
                    left = x; top = gTop; right = x + w; bottom = gBottom
                    open = true
                } else {
                    left = min(left, x)
                    top = min(top, gTop)
                    right = max(right, x + w)
                    bottom = max(bottom, gBottom)
                }
                sb.append(text)
                lastRight = x + w
                lastBaseline = baseline
                lastH = h
            }
            flush()
            return words
        }
    }
}
