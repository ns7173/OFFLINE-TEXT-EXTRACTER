package com.nitesh.offlineocr

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val viewModel: OcrViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        clearOldCameraFiles()
        setContent {
            val colors = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = colors) {
                var crashReport by remember { mutableStateOf(CrashReport.read(this@MainActivity)) }
                OcrScreen(viewModel)
                crashReport?.let { report ->
                    CrashDialog(report) {
                        CrashReport.clear(this@MainActivity)
                        crashReport = null
                    }
                }
            }
        }
    }

    /** Camera shots are only needed for the scan itself; drop any older than a day. */
    private fun clearOldCameraFiles() {
        val cutoff = System.currentTimeMillis() - 24 * 60 * 60 * 1000
        File(cacheDir, "images").listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OcrScreen(vm: OcrViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbar.showSnackbar(it)
            vm.clearError()
        }
    }

    LaunchedEffect(state.notice) {
        state.notice?.let {
            snackbar.showSnackbar(it)
            vm.clearNotice()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(20)
    ) { uris -> if (uris.isNotEmpty()) vm.openImages(uris) }

    val pdfPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.openPdf(uri) }

    val camera = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { saved -> if (saved) cameraUri?.let { vm.openImages(listOf(it)) } }

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) scope.launch {
            val text = vm.state.value.text
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use {
                        it.write(text.toByteArray(Charsets.UTF_8))
                    } ?: error("no stream")
                }.isSuccess
            }
            snackbar.showSnackbar(if (ok) "Saved" else "Could not save the file")
        }
    }

    val docxSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
    ) { uri -> if (uri != null) vm.export(uri, ExportFormat.DOCX) }

    val xlsxSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
    ) { uri -> if (uri != null) vm.export(uri, ExportFormat.XLSX) }

    val pdfSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> if (uri != null) vm.export(uri, ExportFormat.PDF) }

    val scanSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.saveScan(uri) }

    val scanOpener = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.loadScan(uri) }

    fun startCamera() {
        try {
            val dir = File(context.cacheDir, "images").apply { mkdirs() }
            val file = File.createTempFile("scan_", ".jpg", dir)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            cameraUri = uri
            camera.launch(uri)
        } catch (e: Exception) {
            scope.launch { snackbar.showSnackbar("No camera app available") }
        }
    }

    val actions = ScreenActions(
        camera = { startCamera() },
        photos = {
            imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        },
        pdf = { pdfPicker.launch(arrayOf("application/pdf")) },
        openScan = { scanOpener.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
        saveTxt = { saver.launch("extracted-text.txt") },
        saveDocx = { docxSaver.launch("scan.docx") },
        saveXlsx = { xlsxSaver.launch("scan.xlsx") },
        savePdf = { pdfSaver.launch("scan.pdf") },
        saveScan = { scanSaver.launch("scan-data.json") },
        copy = {
            clipboard.setText(AnnotatedString(vm.state.value.text))
            scope.launch { snackbar.showSnackbar("Copied") }
        },
        share = {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, vm.state.value.text)
            }
            context.startActivity(Intent.createChooser(send, "Share text"))
        },
    )

    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val preview = state.preview
    if (preview != null) {
        PreviewScreen(vm, preview, state.script)
    } else Scaffold(
        topBar = { TopAppBar(title = { Text("Offline Text Extractor") }) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        if (wide) WideLayout(state, vm, actions, Modifier.padding(padding))
        else PhoneLayout(state, vm, actions, Modifier.padding(padding))
    }
}

/** Everything the screen can ask the activity to do (pickers, savers, clipboard). */
private class ScreenActions(
    val camera: () -> Unit,
    val photos: () -> Unit,
    val pdf: () -> Unit,
    val openScan: () -> Unit,
    val saveTxt: () -> Unit,
    val saveDocx: () -> Unit,
    val saveXlsx: () -> Unit,
    val savePdf: () -> Unit,
    val saveScan: () -> Unit,
    val copy: () -> Unit,
    val share: () -> Unit,
)

private val COMPACT = PaddingValues(horizontal = 8.dp, vertical = 8.dp)

// ----- phone: the text box takes all the free space; controls are one slim bar at the top and one at the bottom -----

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PhoneLayout(state: UiState, vm: OcrViewModel, a: ScreenActions, modifier: Modifier) {
    var showOptions by rememberSaveable { mutableStateOf(false) }
    val hasText = state.text.isNotBlank()
    val canExport = state.hasLayout && !state.busy

    Column(
        modifier = modifier
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PickRow(state, a)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LanguageChips(state, vm)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showOptions = true }) { Text("Options", maxLines = 1) }
        }
        if (state.busy) ProgressBlock(state, vm)

        ResultBox(state, vm, Modifier.weight(1f).fillMaxWidth().heightIn(min = 160.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = a.copy, enabled = hasText, contentPadding = COMPACT, modifier = Modifier.weight(1f),
            ) { Text("Copy", maxLines = 1) }
            OutlinedButton(
                onClick = a.share, enabled = hasText, contentPadding = COMPACT, modifier = Modifier.weight(1f),
            ) { Text("Share", maxLines = 1) }
            MenuButton("Save ▾", primary = true, modifier = Modifier.weight(1f)) { close ->
                MenuItem("Text (.txt)", hasText, close, a.saveTxt)
                MenuItem("Word (.docx)", canExport, close, a.saveDocx)
                MenuItem("Excel (.xlsx)", canExport, close, a.saveXlsx)
                MenuItem("Searchable PDF (looks like the scan)", state.hasPdf && !state.busy, close, a.savePdf)
                MenuItem("Scan data (.json)", canExport, close, a.saveScan)
            }
            MenuButton("More ▾", primary = false, modifier = Modifier.weight(1f)) { close ->
                MenuItem("Preview / change pages and areas", state.hasSource && !state.busy, close) { vm.reopenPreview() }
                MenuItem("Open a saved scan", !state.busy, close, a.openScan)
                MenuItem("Clear text", hasText && !state.busy, close) { vm.clearText() }
            }
        }
    }

    if (showOptions) {
        ModalBottomSheet(
            onDismissRequest = { showOptions = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Word / Excel options", style = MaterialTheme.typography.titleMedium)
                OptionChips(state, vm)
                OptionHelp()
                if (!state.hasLayout) {
                    Text(
                        "These apply once a scan is read. Word, Excel and PDF files are made from the scan.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Button(onClick = { showOptions = false }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            }
        }
    }
}

// ----- wide screens (tablet, Chromebook, desktop window): controls on the left, big text box on the right -----

@Composable
private fun WideLayout(state: UiState, vm: OcrViewModel, a: ScreenActions, modifier: Modifier) {
    val hasText = state.text.isNotBlank()
    val canExport = state.hasLayout && !state.busy

    Row(
        modifier = modifier
            .padding(16.dp)
            .fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(
            modifier = Modifier
                .width(360.dp)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Read", style = MaterialTheme.typography.titleMedium)
            LanguageChips(state, vm)
            PickRow(state, a)
            OutlinedButton(
                onClick = { vm.reopenPreview() },
                enabled = state.hasSource && !state.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Preview / change pages and areas", maxLines = 1) }
            TextButton(onClick = a.openScan, enabled = !state.busy) { Text("Open a saved scan") }
            if (state.busy) ProgressBlock(state, vm)

            HorizontalDivider()
            Text("Word / Excel options", style = MaterialTheme.typography.titleMedium)
            OptionChips(state, vm)
            OptionHelp()

            HorizontalDivider()
            Text("Save", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = a.saveDocx, enabled = canExport, modifier = Modifier.weight(1f)) {
                    Text("Word", maxLines = 1)
                }
                Button(onClick = a.saveXlsx, enabled = canExport, modifier = Modifier.weight(1f)) {
                    Text("Excel", maxLines = 1)
                }
            }
            Button(
                onClick = a.savePdf,
                enabled = state.hasPdf && !state.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Searchable PDF", maxLines = 1) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = a.saveTxt, enabled = hasText, modifier = Modifier.weight(1f)) {
                    Text("Text .txt", maxLines = 1)
                }
                OutlinedButton(onClick = a.saveScan, enabled = canExport, modifier = Modifier.weight(1f)) {
                    Text("Scan data", maxLines = 1)
                }
            }

            HorizontalDivider()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = a.copy, enabled = hasText, modifier = Modifier.weight(1f)) {
                    Text("Copy", maxLines = 1)
                }
                OutlinedButton(onClick = a.share, enabled = hasText, modifier = Modifier.weight(1f)) {
                    Text("Share", maxLines = 1)
                }
                OutlinedButton(
                    onClick = { vm.clearText() },
                    enabled = hasText && !state.busy,
                    modifier = Modifier.weight(1f),
                ) { Text("Clear", maxLines = 1) }
            }
        }

        ResultBox(state, vm, Modifier.weight(1f).fillMaxHeight())
    }
}

// ----- shared pieces ------------------------------------------------------------------------------------

@Composable
private fun PickRow(state: UiState, a: ScreenActions) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
            onClick = a.camera, enabled = !state.busy, contentPadding = COMPACT, modifier = Modifier.weight(1f),
        ) { Text("Camera", maxLines = 1) }
        FilledTonalButton(
            onClick = a.photos, enabled = !state.busy, contentPadding = COMPACT, modifier = Modifier.weight(1f),
        ) { Text("Photos", maxLines = 1) }
        FilledTonalButton(
            onClick = a.pdf, enabled = !state.busy, contentPadding = COMPACT, modifier = Modifier.weight(1f),
        ) { Text("PDF", maxLines = 1) }
    }
}

@Composable
private fun LanguageChips(state: UiState, vm: OcrViewModel) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = state.script == Script.DEVANAGARI,
            onClick = { vm.setScript(Script.DEVANAGARI) },
            enabled = !state.busy,
            label = { Text("हिन्दी/मराठी + English", maxLines = 1) },
        )
        FilterChip(
            selected = state.script == Script.LATIN,
            onClick = { vm.setScript(Script.LATIN) },
            enabled = !state.busy,
            label = { Text("English", maxLines = 1) },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OptionChips(state: UiState, vm: OcrViewModel) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = state.options.auto,
            onClick = { vm.setAuto(!state.options.auto) },
            label = { Text("Auto", maxLines = 1) },
        )
        FilterChip(
            selected = state.options.tables,
            onClick = { vm.setTables(!state.options.tables) },
            label = { Text("Tables", maxLines = 1) },
        )
        FilterChip(
            selected = state.options.borders,
            onClick = { vm.setBorders(!state.options.borders) },
            enabled = state.options.tables,
            label = { Text("Borders", maxLines = 1) },
        )
        FilterChip(
            selected = state.options.keepLineBreaks,
            onClick = { vm.setKeepLineBreaks(!state.options.keepLineBreaks) },
            label = { Text("Keep line breaks", maxLines = 1) },
        )
    }
}

@Composable
private fun OptionHelp() {
    Text(
        "Auto: real data tables get borders; aligned labels and signature blocks do not.\n" +
            "Tables: off keeps aligned pieces in one line with tabs.\n" +
            "Borders: off removes all table borders.\n" +
            "Keep line breaks: every scanned line stays its own paragraph.",
        style = MaterialTheme.typography.bodySmall,
    )
}

@Composable
private fun ProgressBlock(state: UiState, vm: OcrViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(state.progress, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { vm.cancel() }) { Text("Cancel") }
        }
    }
}

/** The extracted text: as large as the space allows, editable. */
@Composable
private fun ResultBox(state: UiState, vm: OcrViewModel, modifier: Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedTextField(
            value = state.text,
            onValueChange = vm::onTextChange,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp),
            placeholder = { Text("Extracted text appears here. You can edit it before copying or saving.") },
        )
        if (state.hasLayout && state.text != state.scanText) {
            Text(
                "Word, Excel and PDF use the original scan; your edits here are not included.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

/** A button that opens a small menu; [content] receives a function that closes the menu. */
@Composable
private fun MenuButton(
    label: String,
    primary: Boolean,
    modifier: Modifier,
    content: @Composable (close: () -> Unit) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        if (primary) {
            Button(onClick = { open = true }, contentPadding = COMPACT, modifier = Modifier.fillMaxWidth()) {
                Text(label, maxLines = 1)
            }
        } else {
            OutlinedButton(onClick = { open = true }, contentPadding = COMPACT, modifier = Modifier.fillMaxWidth()) {
                Text(label, maxLines = 1)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) { content { open = false } }
    }
}

@Composable
private fun MenuItem(text: String, enabled: Boolean, close: () -> Unit, action: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text) },
        enabled = enabled,
        onClick = {
            close()
            action()
        },
    )
}
