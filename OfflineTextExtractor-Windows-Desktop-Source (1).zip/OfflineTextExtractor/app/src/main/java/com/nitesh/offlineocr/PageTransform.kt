package com.nitesh.offlineocr

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Turns a photographed page into a flat, level picture: rotate by 90s, flatten the page corners, then straighten. */
object PageTransform {

    /** Longest side allowed for a flattened page, so memory stays bounded. */
    private const val MAX_OUT = 3600

    /** Flattens the area inside [quad] into a rectangle. Returns [base] itself when the quad is the whole picture. */
    fun warp(base: Bitmap, quad: Quad): Bitmap {
        if (quad.isFull()) return base
        val w = base.width.toFloat()
        val h = base.height.toFloat()
        val src = floatArrayOf(
            quad.tl.x * w, quad.tl.y * h,
            quad.tr.x * w, quad.tr.y * h,
            quad.br.x * w, quad.br.y * h,
            quad.bl.x * w, quad.bl.y * h,
        )
        val top = hypot(src[2] - src[0], src[3] - src[1])
        val bottom = hypot(src[4] - src[6], src[5] - src[7])
        val left = hypot(src[6] - src[0], src[7] - src[1])
        val right = hypot(src[4] - src[2], src[5] - src[3])
        var outW = (top + bottom) / 2f
        var outH = (left + right) / 2f
        val shrink = min(1f, MAX_OUT / max(outW, outH))
        outW *= shrink
        outH *= shrink
        val ow = outW.roundToInt().coerceAtLeast(16)
        val oh = outH.roundToInt().coerceAtLeast(16)

        val dst = floatArrayOf(0f, 0f, ow.toFloat(), 0f, ow.toFloat(), oh.toFloat(), 0f, oh.toFloat())
        val matrix = Matrix()
        if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) return base

        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(base, matrix, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** Turns the picture clockwise by [degrees] (small angles) on a white canvas of the same size. */
    fun straighten(bitmap: Bitmap, degrees: Float): Bitmap {
        if (abs(degrees) < 0.05f) return bitmap
        val out = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        val matrix = Matrix().apply { postRotate(degrees, bitmap.width / 2f, bitmap.height / 2f) }
        canvas.drawBitmap(bitmap, matrix, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /**
     * The full pipeline: turn by [rotation] degrees (multiple of 90), flatten the page inside [quad],
     * then straighten by [angle]. Never recycles [src]; returns [src] itself when nothing needs doing.
     */
    fun process(src: Bitmap, rotation: Int, quad: Quad, angle: Float): Bitmap {
        var cur = src

        val turned = cur.rotated(rotation)
        cur = turned

        val flat = warp(cur, quad)
        if (flat !== cur) {
            if (cur !== src) cur.recycle()
            cur = flat
        }

        val level = straighten(cur, angle)
        if (level !== cur) {
            if (cur !== src) cur.recycle()
            cur = level
        }
        return cur
    }

    /** A small grayscale copy (longest side at most [maxDim]) for the tilt and page-edge detectors. */
    fun toGray(bitmap: Bitmap, maxDim: Int): GrayImage {
        val scale = min(1f, maxDim.toFloat() / max(bitmap.width, bitmap.height))
        val w = max(1, (bitmap.width * scale).roundToInt())
        val h = max(1, (bitmap.height * scale).roundToInt())
        val small = if (scale < 1f) Bitmap.createScaledBitmap(bitmap, w, h, true) else bitmap
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== bitmap) small.recycle()
        val gray = IntArray(px.size) {
            val c = px[it]
            (77 * ((c shr 16) and 255) + 150 * ((c shr 8) and 255) + 29 * (c and 255)) shr 8
        }
        return GrayImage(w, h, gray)
    }
}
