package com.nitesh.offlineocr

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.abs
import kotlin.math.max

enum class ExportFormat { DOCX, XLSX, PDF }

/** Which pages of the file to read. */
enum class PageScope { ALL, CURRENT, RANGE }

/** What the preview screen is doing: choosing areas, placing the page corners, or levelling the text. */
enum class PreviewMode { SELECT, CROP, STRAIGHTEN }

/**
 * The preview screen. Each page has: a 90-degree rotation, optional page corners (flattened into a
 * rectangle), an optional small straightening angle, and the areas chosen on the finished page.
 */
data class PreviewState(
    val pageCount: Int,
    val isPdf: Boolean,
    val current: Int = 0,
    /** Clockwise rotation per page index, in degrees (0, 90, 180, 270). */
    val rotations: Map<Int, Int> = emptyMap(),
    /** Page corners per page index, in the rotated photo. Missing means the whole photo. */
    val quads: Map<Int, Quad> = emptyMap(),
    /** Straightening per page index in degrees clockwise. Missing means none. */
    val skews: Map<Int, Float> = emptyMap(),
    /** Selected areas per page index, on the finished (flattened, level) page, in reading order. */
    val areas: Map<Int, List<NormRect>> = emptyMap(),
    val scope: PageScope = PageScope.ALL,
    val rangeText: String = "",
    /** The finished page as shown on screen. */
    val bitmap: Bitmap? = null,
    val loading: Boolean = true,
    val mode: PreviewMode = PreviewMode.SELECT,
    /** CROP mode: the rotated photo before cropping, and the corners being edited. */
    val baseBitmap: Bitmap? = null,
    val editQuad: Quad = Quad.FULL,
    /** STRAIGHTEN mode: the flattened page before straightening, and the angle being edited. */
    val flatBitmap: Bitmap? = null,
    val editAngle: Float = 0f,
    /** True while corners or tilt are being detected automatically. */
    val detecting: Boolean = false,
)

data class UiState(
    val script: Script = Script.DEVANAGARI,
    val text: String = "",
    /** The text exactly as scanned, to tell whether the user has edited it since. */
    val scanText: String = "",
    /** True when a scan with word positions is available for Word/Excel export. */
    val hasLayout: Boolean = false,
    /** True when the scanned page pictures are still available, so a searchable PDF can be saved. */
    val hasPdf: Boolean = false,
    /** True while a picked file is open, so its pages/areas can be changed and re-read. */
    val hasSource: Boolean = false,
    /** Non-null while the preview screen is showing. */
    val preview: PreviewState? = null,
    val busy: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val notice: String? = null,
    /** How Word / Excel files are rebuilt from the scan. */
    val options: ExportOptions = ExportOptions(),
)

internal class ScanOutput(val text: String, val pages: List<ScannedPage>, val pdf: List<PdfPageInput> = emptyList())

class OcrViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = OcrEngine()
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null
    private var previewJob: Job? = null
    private var source: PageSource? = null
    private var lastPreview: PreviewState? = null

    /** The page being previewed, upright and at preview size, before any rotation/crop/straightening. */
    private var currentSrc: Bitmap? = null

    /** Word positions from the latest scan, one entry per page read. */
    private var pages: List<ScannedPage> = emptyList()

    /** Page pictures (JPEG files in the cache) with their words, for the searchable PDF. */
    private var pdfPages: List<PdfPageInput> = emptyList()

    private fun pdfDir() = File(getApplication<Application>().cacheDir, "scanpdf")

    private fun clearPdfPages() {
        pdfPages = emptyList()
        pdfDir().listFiles()?.forEach { it.delete() }
    }

    fun setScript(script: Script) = _state.update { it.copy(script = script) }
    fun onTextChange(text: String) = _state.update { it.copy(text = text) }
    fun clearError() = _state.update { it.copy(error = null) }
    fun clearNotice() = _state.update { it.copy(notice = null) }
    fun cancel() { job?.cancel() }

    fun setTables(on: Boolean) = _state.update { it.copy(options = it.options.copy(tables = on)) }
    fun setAuto(on: Boolean) = _state.update { it.copy(options = it.options.copy(auto = on)) }
    fun setBorders(on: Boolean) = _state.update { it.copy(options = it.options.copy(borders = on)) }
    fun setKeepLineBreaks(on: Boolean) = _state.update { it.copy(options = it.options.copy(keepLineBreaks = on)) }

    fun clearText() {
        pages = emptyList()
        clearPdfPages()
        _state.update { it.copy(text = "", scanText = "", hasLayout = false, hasPdf = false) }
    }

    // ----- opening a file ---------------------------------------------------------------------

    fun openImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        showPreviewFor(PageSource.images(getApplication(), uris))
    }

    fun openPdf(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = "Opening PDF…", error = null) }
            try {
                val opened = PageSource.pdf(getApplication(), uri)
                _state.update { it.copy(busy = false, progress = "") }
                showPreviewFor(opened)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, progress = "", error = e.message ?: "Could not open the PDF") }
            }
        }
    }

    private fun showPreviewFor(newSource: PageSource) {
        job?.cancel()
        previewJob?.cancel()
        source?.close()
        source = newSource
        lastPreview = null
        currentSrc = null
        _state.update {
            it.copy(
                hasSource = true,
                preview = PreviewState(pageCount = newSource.pageCount, isPdf = newSource.isPdf),
            )
        }
        loadPreview(0)
    }

    /** Re-opens the preview of the file already picked, keeping rotations, corners, tilt and areas. */
    fun reopenPreview() {
        val src = source ?: return
        val base = lastPreview ?: PreviewState(pageCount = src.pageCount, isPdf = src.isPdf)
        _state.update {
            it.copy(
                preview = base.copy(
                    bitmap = null, loading = true, mode = PreviewMode.SELECT,
                    baseBitmap = null, flatBitmap = null, detecting = false,
                )
            )
        }
        loadPreview(base.current)
    }

    /** Leaves the preview screen without reading anything; the selection is remembered. */
    fun cancelPreview() {
        previewJob?.cancel()
        _state.value.preview?.let {
            lastPreview = it.copy(
                bitmap = null, mode = PreviewMode.SELECT, baseBitmap = null, flatBitmap = null, detecting = false,
            )
        }
        _state.update { it.copy(preview = null) }
    }

    // ----- preview screen: pages and rotation ------------------------------------------------------

    private fun loadPreview(index: Int) {
        val src = source ?: return
        previewJob?.cancel()
        _state.update { s ->
            s.copy(preview = s.preview?.copy(current = index, loading = true, bitmap = null, mode = PreviewMode.SELECT))
        }
        previewJob = viewModelScope.launch {
            try {
                val loaded = src.load(index, PREVIEW_MAX_DIM) ?: throw IOException("Could not open page ${index + 1}")
                currentSrc = loaded
                val p = _state.value.preview
                val shown = withContext(Dispatchers.Default) {
                    PageTransform.process(
                        loaded,
                        p?.rotations?.get(index) ?: 0,
                        p?.quads?.get(index) ?: Quad.FULL,
                        p?.skews?.get(index) ?: 0f,
                    )
                }
                _state.update { s ->
                    val cur = s.preview
                    if (cur != null && cur.current == index) s.copy(preview = cur.copy(bitmap = shown, loading = false)) else s
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { s ->
                    s.copy(error = e.message ?: "Could not load the page", preview = s.preview?.copy(loading = false))
                }
            }
        }
    }

    private fun updatePreview(transform: (PreviewState) -> PreviewState) =
        _state.update { s -> s.preview?.let { s.copy(preview = transform(it)) } ?: s }

    fun nextPage() {
        val p = _state.value.preview ?: return
        if (p.current < p.pageCount - 1) loadPreview(p.current + 1)
    }

    fun prevPage() {
        val p = _state.value.preview ?: return
        if (p.current > 0) loadPreview(p.current - 1)
    }

    /** Turns the current page 90 degrees clockwise; its corners and areas turn with it. */
    fun rotateCurrent() {
        val p = _state.value.preview ?: return
        val turned = p.bitmap?.rotated(90)
        updatePreview {
            val i = it.current
            it.copy(
                rotations = it.rotations + (i to (((it.rotations[i] ?: 0) + 90) % 360)),
                quads = it.quads[i]?.let { q -> it.quads + (i to q.rotatedCw()) } ?: it.quads,
                areas = it.areas + (i to it.areas[i].orEmpty().map { a -> a.rotatedCw() }),
                bitmap = turned ?: it.bitmap,
            )
        }
    }

    /** Turns every page 90 degrees clockwise. */
    fun rotateAll() {
        val p = _state.value.preview ?: return
        val turned = p.bitmap?.rotated(90)
        updatePreview {
            it.copy(
                rotations = (0 until it.pageCount).associateWith { i -> ((it.rotations[i] ?: 0) + 90) % 360 },
                quads = it.quads.mapValues { (_, q) -> q.rotatedCw() },
                areas = it.areas.mapValues { (_, list) -> list.map { a -> a.rotatedCw() } },
                bitmap = turned ?: it.bitmap,
            )
        }
    }

    // ----- preview screen: areas ---------------------------------------------------------------------

    fun addArea(area: NormRect) = updatePreview {
        it.copy(areas = it.areas + (it.current to (it.areas[it.current].orEmpty() + area)))
    }

    fun undoArea() = updatePreview {
        it.copy(areas = it.areas + (it.current to it.areas[it.current].orEmpty().dropLast(1)))
    }

    fun clearAreas() = updatePreview { it.copy(areas = it.areas - it.current) }

    /** Replaces the current page's areas with [count] equal columns (1 means: no areas, read the whole page). */
    fun splitColumns(count: Int) = updatePreview {
        if (count <= 1) it.copy(areas = it.areas - it.current)
        else it.copy(areas = it.areas + (it.current to columnRects(count)))
    }

    /** Copies the current page's areas to every page (useful when all pages share one layout and rotation). */
    fun copyAreasToAll() = updatePreview {
        val mine = it.areas[it.current].orEmpty()
        it.copy(areas = (0 until it.pageCount).associateWith { mine })
    }

    fun setScope(scope: PageScope) = updatePreview { it.copy(scope = scope) }
    fun setRange(text: String) = updatePreview { it.copy(rangeText = text) }

    // ----- preview screen: crop (flatten the page) ---------------------------------------------------

    fun enterCrop() {
        val p = _state.value.preview ?: return
        val src = currentSrc ?: return
        val base = src.rotated(p.rotations[p.current] ?: 0)
        updatePreview {
            it.copy(mode = PreviewMode.CROP, baseBitmap = base, editQuad = it.quads[it.current] ?: Quad.FULL)
        }
    }

    fun setEditQuad(quad: Quad) = updatePreview { it.copy(editQuad = quad) }

    fun resetCrop() = updatePreview { it.copy(editQuad = Quad.FULL) }

    /** Looks for the page edges in the photo and moves the corners onto them. */
    fun autoCrop() {
        val base = _state.value.preview?.baseBitmap ?: return
        viewModelScope.launch {
            updatePreview { it.copy(detecting = true) }
            val found = withContext(Dispatchers.Default) {
                PageGeometry.detectPageQuad(PageTransform.toGray(base, 250))
            }
            _state.update { s ->
                s.copy(
                    preview = s.preview?.let { pv -> pv.copy(detecting = false, editQuad = found ?: pv.editQuad) },
                    notice = if (found == null) "Couldn't find the page edges. Drag the corners onto the page instead." else s.notice,
                )
            }
        }
    }

    fun applyCrop() {
        val p = _state.value.preview ?: return
        val src = currentSrc ?: return
        val quad = p.editQuad
        if (!quad.isFull() && (!quad.isConvex() || quad.area() < 0.05f)) {
            _state.update { it.copy(error = "The corners are crossed or too close together. Drag them onto the page corners.") }
            return
        }
        val i = p.current
        val hadAreas = p.areas[i].orEmpty().isNotEmpty()
        viewModelScope.launch {
            val shown = withContext(Dispatchers.Default) {
                PageTransform.process(src, p.rotations[i] ?: 0, quad, 0f)
            }
            updatePreview {
                it.copy(
                    quads = if (quad.isFull()) it.quads - i else it.quads + (i to quad),
                    skews = it.skews - i, // the page changed, so an old tilt correction no longer applies
                    areas = it.areas - i,
                    bitmap = shown,
                    mode = PreviewMode.SELECT,
                    baseBitmap = null,
                )
            }
            if (hadAreas) _state.update { it.copy(notice = "Areas on this page were cleared because the page changed.") }
        }
    }

    // ----- preview screen: straighten ----------------------------------------------------------------

    fun enterStraighten() {
        val p = _state.value.preview ?: return
        val src = currentSrc ?: return
        val i = p.current
        viewModelScope.launch {
            val flat = withContext(Dispatchers.Default) {
                PageTransform.process(src, p.rotations[i] ?: 0, p.quads[i] ?: Quad.FULL, 0f)
            }
            updatePreview {
                it.copy(mode = PreviewMode.STRAIGHTEN, flatBitmap = flat, editAngle = it.skews[i] ?: 0f)
            }
        }
    }

    fun setEditAngle(degrees: Float) = updatePreview { it.copy(editAngle = degrees) }

    /** Measures the tilt of the text lines and sets the slider to cancel it out. */
    fun autoStraighten() {
        val flat = _state.value.preview?.flatBitmap ?: return
        viewModelScope.launch {
            updatePreview { it.copy(detecting = true) }
            val skew = withContext(Dispatchers.Default) {
                PageGeometry.estimateSkew(PageTransform.toGray(flat, 800))
            }
            _state.update { s ->
                s.copy(
                    preview = s.preview?.let { pv ->
                        pv.copy(
                            detecting = false,
                            editAngle = if (skew != null) (-skew).coerceIn(-15f, 15f) else pv.editAngle,
                        )
                    },
                    notice = if (skew == null) "Not enough straight lines of text to measure the tilt. Use the slider instead." else s.notice,
                )
            }
        }
    }

    fun applyStraighten() {
        val p = _state.value.preview ?: return
        val src = currentSrc ?: return
        val i = p.current
        val angle = p.editAngle
        val changed = abs(angle - (p.skews[i] ?: 0f)) >= 0.05f
        val hadAreas = p.areas[i].orEmpty().isNotEmpty()
        viewModelScope.launch {
            val shown = withContext(Dispatchers.Default) {
                PageTransform.process(src, p.rotations[i] ?: 0, p.quads[i] ?: Quad.FULL, angle)
            }
            updatePreview {
                it.copy(
                    skews = if (abs(angle) < 0.05f) it.skews - i else it.skews + (i to angle),
                    areas = if (changed) it.areas - i else it.areas,
                    bitmap = shown,
                    mode = PreviewMode.SELECT,
                    flatBitmap = null,
                )
            }
            if (changed && hadAreas) {
                _state.update { it.copy(notice = "Areas on this page were cleared because the page changed.") }
            }
        }
    }

    /** Leaves crop / straighten without keeping the changes. */
    fun cancelEdit() = updatePreview {
        it.copy(mode = PreviewMode.SELECT, baseBitmap = null, flatBitmap = null, detecting = false)
    }

    // ----- reading -----------------------------------------------------------------------------

    /** Reads the chosen pages, and within each page the chosen areas (or the whole page if none). */
    fun extract() {
        val p = _state.value.preview ?: return
        val src = source ?: return
        val targets = when (p.scope) {
            PageScope.ALL -> (0 until p.pageCount).toList()
            PageScope.CURRENT -> listOf(p.current)
            PageScope.RANGE -> parsePageRange(p.rangeText, p.pageCount)
        }
        if (targets.isNullOrEmpty()) {
            _state.update { it.copy(error = "Enter pages like 1-3, 5 (this file has ${p.pageCount})") }
            return
        }
        previewJob?.cancel()
        lastPreview = p.copy(
            bitmap = null, mode = PreviewMode.SELECT, baseBitmap = null, flatBitmap = null, detecting = false,
        )
        _state.update { it.copy(preview = null) }

        launchScan { script ->
            val out = StringBuilder()
            val scanned = ArrayList<ScannedPage>()
            val pdf = ArrayList<PdfPageInput>()
            withContext(Dispatchers.IO) { clearPdfPages(); pdfDir().mkdirs() }
            targets.forEachIndexed { n, index ->
                setProgress(if (targets.size > 1) "Reading page ${index + 1} (${n + 1} of ${targets.size})" else "Reading…")
                val loaded = src.load(index, OCR_MAX_DIM) ?: throw IOException("Could not open page ${index + 1}")
                // The same rotate / flatten / straighten steps as the preview, at full resolution.
                val upright = withContext(Dispatchers.Default) {
                    PageTransform.process(
                        loaded,
                        p.rotations[index] ?: 0,
                        p.quads[index] ?: Quad.FULL,
                        p.skews[index] ?: 0f,
                    )
                }
                // A digital PDF page that was not turned, flattened or tilted keeps its own text: use it
                // exactly instead of OCR. Anything else (scans, edited pages, photos) goes through OCR.
                val untouched = (p.rotations[index] ?: 0) == 0 &&
                    (p.quads[index] ?: Quad.FULL) == Quad.FULL &&
                    (p.skews[index] ?: 0f) == 0f
                // Ruling lines of a whole PDF page (forms, challans) are used to lay out its tables.
                val rules = if (src.isPdf && p.areas[index].isNullOrEmpty()) detectRules(upright) else emptyList()
                val embedded = if (untouched && src.isPdf) {
                    src.embeddedWords(index, upright.width, upright.height)
                } else null
                try {
                    val (text, page) = if (embedded != null) {
                        readEmbeddedPage(upright, embedded, p.areas[index].orEmpty(), rules)
                    } else {
                        readPage(upright, p.areas[index].orEmpty(), script, rules)
                    }
                    scanned.add(page)
                    withContext(Dispatchers.IO) {
                        val file = File(pdfDir(), "page_${n + 1}.jpg")
                        FileOutputStream(file).use { upright.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                        pdf.add(PdfPageInput(file, upright.width, upright.height, page.areas.flatMap { a -> a.words }))
                    }
                    out.appendPage(if (targets.size > 1) "Page ${index + 1}" else null, text)
                } finally {
                    if (upright !== loaded) upright.recycle()
                    loaded.recycle()
                }
            }
            ScanOutput(out.toString(), scanned, pdf)
        }
    }

    /** OCR of one upright page: each area in order, or the whole page when [areas] is empty. */
    private suspend fun readPage(
        page: Bitmap, areas: List<NormRect>, script: Script, rules: List<Rule> = emptyList(),
    ): Pair<String, ScannedPage> {
        val regions = areas.ifEmpty { listOf(NormRect(0f, 0f, 1f, 1f)) }
        val texts = ArrayList<String>()
        val parts = ArrayList<OcrPage>()
        for (region in regions) {
            val box = region.toPixels(page.width, page.height) ?: continue
            val isWhole = box.x == 0 && box.y == 0 && box.w == page.width && box.h == page.height
            val crop = if (isWhole) page else Bitmap.createBitmap(page, box.x, box.y, box.w, box.h)
            val result = try {
                engine.recognize(crop, script)
            } finally {
                if (crop !== page) crop.recycle()
            }
            if (result.text.isNotBlank()) texts.add(result.text.trim())
            // Put the words back into full-page pixel coordinates.
            val words = result.page.words.map { it.shifted(box.x.toFloat(), box.y.toFloat()) }
            parts.add(OcrPage(page.width, page.height, withStyles(page, words), if (areas.isEmpty()) rules else emptyList()))
        }
        return texts.joinToString("\n\n") to ScannedPage(parts, cropped = areas.isNotEmpty())
    }

    /** Same as [readPage], but the words come from the PDF's own text, so nothing is recognized again. */
    private fun readEmbeddedPage(
        page: Bitmap, textPage: OcrPage, areas: List<NormRect>, rules: List<Rule> = emptyList(),
    ): Pair<String, ScannedPage> {
        val regions = areas.ifEmpty { listOf(NormRect(0f, 0f, 1f, 1f)) }
        val texts = ArrayList<String>()
        val parts = ArrayList<OcrPage>()
        for (region in regions) {
            val box = region.toPixels(page.width, page.height) ?: continue
            val words = OcrText.wordsInside(textPage.words, box.x, box.y, box.x + box.w, box.y + box.h)
            val text = OcrText.linesToText(words)
            if (text.isNotBlank()) texts.add(text.trim())
            parts.add(OcrPage(page.width, page.height, withStyles(page, words), if (areas.isEmpty()) rules else emptyList()))
        }
        return texts.joinToString("\n\n") to ScannedPage(parts, cropped = areas.isNotEmpty())
    }

    /** Ruling lines of a rendered page: long straight dark lines, in pixels of the bitmap. */
    private fun detectRules(bitmap: Bitmap): List<Rule> {
        val w = bitmap.width
        val h = bitmap.height
        val argb = IntArray(w * h)
        bitmap.getPixels(argb, 0, w, 0, 0, w, h)
        return InkMeasure.rules(GrayPage(w, h, RuledGrid.grayFromArgb(argb)), max(20, w / 20))
    }

    /** The words with their bold and underline flags, measured from the page's own pixels. */
    private fun withStyles(bitmap: Bitmap, words: List<OcrWord>): List<OcrWord> {
        if (words.isEmpty()) return words
        val w = bitmap.width
        val h = bitmap.height
        val argb = IntArray(w * h)
        bitmap.getPixels(argb, 0, w, 0, 0, w, h)
        val gray = GrayPage(w, h, RuledGrid.grayFromArgb(argb))
        val boxes = words.map { word ->
            val l = word.left.toInt().coerceIn(0, w - 1)
            val t = word.top.toInt().coerceIn(0, h - 1)
            PixelBox(l, t, word.right.toInt().coerceIn(l + 1, w), word.bottom.toInt().coerceIn(t + 1, h))
        }
        val styles = InkMeasure.styles(gray, boxes)
        return words.mapIndexed { i, word -> word.copy(bold = styles[i].bold, underline = styles[i].underline) }
    }

    /**
     * Writes the last scan to [uri] as a Word or Excel file, rebuilt from word positions
     * (paragraphs, alignment, indents, tables). It uses the scan, not edits made in the text box.
     */
    fun export(uri: Uri, format: ExportFormat) {
        val snapshot = pages
        if (snapshot.isEmpty()) return
        val options = _state.value.options
        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                runCatching {
                    if (format == ExportFormat.PDF) {
                        val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                            ?: throw IOException("Could not open the file for writing")
                        stream.use { PdfWriter.write(pdfPages, it) }
                        return@runCatching
                    }
                    val models = snapshot.map { sp ->
                        mergeModels(sp.areas.map { LayoutAnalyzer.analyze(it, options) }, stackAtMargin = sp.cropped)
                    }
                    val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("Could not open the file for writing")
                    stream.use {
                        when (format) {
                            ExportFormat.DOCX -> DocxWriter.write(models, it, options.borders)
                            ExportFormat.XLSX -> XlsxWriter.write(models, it, options.borders)
                            ExportFormat.PDF -> Unit
                        }
                    }
                }
            }
            val message = if (result.isSuccess) "Saved"
            else "Could not save: ${result.exceptionOrNull()?.message ?: "unknown error"}"
            _state.update { it.copy(notice = message) }
        }
    }

    /** Saves the text and every word position of the last scan, so it can be exported again later without rescanning. */
    fun saveScan(uri: Uri) {
        val snapshot = pages
        if (snapshot.isEmpty()) return
        val text = _state.value.scanText
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("Could not open the file for writing")
                    stream.use { ScanDataIO.write(ScanData(text, snapshot), it) }
                }
            }
            val message = if (result.isSuccess) "Scan data saved"
            else "Could not save: ${result.exceptionOrNull()?.message ?: "unknown error"}"
            _state.update { it.copy(notice = message) }
        }
    }

    /** Opens a scan saved earlier; Word / Excel export then works from it. Closes any picked file. */
    fun loadScan(uri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { ScanDataIO.read(it) }
                        ?: throw IOException("Could not open the file")
                }
            }
            val data = result.getOrNull()
            if (data == null) {
                val e = result.exceptionOrNull()
                _state.update { it.copy(error = e?.message ?: "Could not open the saved scan") }
                return@launch
            }
            job?.cancel()
            previewJob?.cancel()
            source?.close()
            source = null
            lastPreview = null
            currentSrc = null
            pages = data.pages
            clearPdfPages()
            val hasWords = data.pages.any { sp -> sp.areas.any { it.words.isNotEmpty() } }
            _state.update {
                it.copy(
                    text = data.text, scanText = data.text, hasLayout = hasWords, hasPdf = false,
                    hasSource = false, preview = null, busy = false, progress = "",
                    notice = "Saved scan opened",
                )
            }
        }
    }

    private fun launchScan(block: suspend (Script) -> ScanOutput) {
        job?.cancel()
        job = viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = "Starting…", error = null) }
            try {
                val result = block(_state.value.script)
                pages = result.pages
                pdfPages = result.pdf
                val hasWords = result.pages.any { sp -> sp.areas.any { it.words.isNotEmpty() } }
                _state.update {
                    it.copy(
                        text = result.text,
                        scanText = result.text,
                        hasLayout = hasWords,
                        hasPdf = result.pdf.isNotEmpty(),
                        busy = false,
                        progress = "",
                        error = if (result.text.isBlank()) "No text was found. Try a clearer image or a different area." else null,
                    )
                }
            } catch (e: CancellationException) {
                _state.update { it.copy(busy = false, progress = "") }
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, progress = "", error = e.message ?: "Scan failed") }
            }
        }
    }

    private fun setProgress(message: String) = _state.update { it.copy(progress = message) }

    private fun StringBuilder.appendPage(label: String?, text: String) {
        if (isNotEmpty()) append("\n\n")
        if (label != null) append("— $label —\n")
        append(text.trim())
    }

    override fun onCleared() {
        source?.close()
        engine.close()
        super.onCleared()
    }
}
