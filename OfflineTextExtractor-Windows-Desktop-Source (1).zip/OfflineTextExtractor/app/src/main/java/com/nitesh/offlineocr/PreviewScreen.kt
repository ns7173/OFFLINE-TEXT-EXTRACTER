package com.nitesh.offlineocr

import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private val AreaBlue = Color(0xFF1F6FEB)
private val HandleTeal = Color(0xFF14B8A6)

/**
 * The preview screen. In SELECT mode it shows the page, lets the user rotate it, flip pages, and
 * drag out numbered boxes over the parts to read (no box means the whole page is read). CROP mode
 * places the four page corners so the page is flattened; STRAIGHTEN mode levels tilted text lines.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(vm: OcrViewModel, p: PreviewState, script: Script) {
    BackHandler { if (p.mode == PreviewMode.SELECT) vm.cancelPreview() else vm.cancelEdit() }

    val image = remember(p.bitmap) { p.bitmap?.asImageBitmap() }
    val baseImage = remember(p.baseBitmap) { p.baseBitmap?.asImageBitmap() }
    val flatImage = remember(p.flatBitmap) { p.flatBitmap?.asImageBitmap() }
    val pageAreas = p.areas[p.current].orEmpty()
    val select = p.mode == PreviewMode.SELECT

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (p.mode) {
                            PreviewMode.CROP -> "Crop"
                            PreviewMode.STRAIGHTEN -> "Straighten"
                            PreviewMode.SELECT -> if (p.pageCount > 1) "Page ${p.current + 1} / ${p.pageCount}" else "Preview"
                        }
                    )
                },
                navigationIcon = {
                    TextButton(onClick = { if (select) vm.cancelPreview() else vm.cancelEdit() }) {
                        Text(if (select) "Back" else "Cancel")
                    }
                },
                actions = {
                    if (select) {
                        TextButton(
                            onClick = {
                                vm.setScript(if (script == Script.DEVANAGARI) Script.LATIN else Script.DEVANAGARI)
                            }
                        ) { Text(if (script == Script.DEVANAGARI) "हिन्दी + EN" else "English") }
                        TextButton(onClick = { vm.rotateCurrent() }, enabled = !p.loading) { Text("Rotate ↻") }
                    }
                },
            )
        },
        bottomBar = {
            when (p.mode) {
                PreviewMode.SELECT -> PreviewControls(vm, p, pageAreas.size)
                PreviewMode.CROP -> CropControls(vm, p)
                PreviewMode.STRAIGHTEN -> StraightenControls(vm, p)
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFF1E1E1E)),
        ) {
            when (p.mode) {
                PreviewMode.SELECT -> PageCanvas(
                    image = image,
                    areas = pageAreas,
                    onAdd = { vm.addArea(it) },
                    modifier = Modifier.fillMaxSize(),
                )
                PreviewMode.CROP -> CropCanvas(
                    image = baseImage,
                    quad = p.editQuad,
                    onChange = { vm.setEditQuad(it) },
                    modifier = Modifier.fillMaxSize(),
                )
                PreviewMode.STRAIGHTEN -> StraightenCanvas(
                    image = flatImage,
                    angle = p.editAngle,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            if (p.loading || p.detecting) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

// ----- bottom controls ----------------------------------------------------------------------------

@Composable
private fun PreviewControls(vm: OcrViewModel, p: PreviewState, areaCount: Int) {
    var columnsMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val rangeOk = p.scope != PageScope.RANGE || parsePageRange(p.rangeText, p.pageCount) != null

    Surface(tonalElevation = 3.dp) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (p.pageCount > 1) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(onClick = { vm.prevPage() }, enabled = p.current > 0) { Text("◀") }
                    Text(
                        "Page ${p.current + 1} of ${p.pageCount}",
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                    )
                    OutlinedButton(onClick = { vm.nextPage() }, enabled = p.current < p.pageCount - 1) { Text("▶") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = p.scope == PageScope.ALL,
                        onClick = { vm.setScope(PageScope.ALL) },
                        label = { Text("All pages") },
                    )
                    FilterChip(
                        selected = p.scope == PageScope.CURRENT,
                        onClick = { vm.setScope(PageScope.CURRENT) },
                        label = { Text("This page") },
                    )
                    FilterChip(
                        selected = p.scope == PageScope.RANGE,
                        onClick = { vm.setScope(PageScope.RANGE) },
                        label = { Text("Pages…") },
                    )
                }
                if (p.scope == PageScope.RANGE) {
                    OutlinedTextField(
                        value = p.rangeText,
                        onValueChange = { vm.setRange(it) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = !rangeOk,
                        label = { Text("Pages, e.g. 1-3, 5") },
                    )
                }
            }

            val tight = PaddingValues(horizontal = 4.dp, vertical = 8.dp)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.enterCrop() },
                    enabled = !p.loading,
                    contentPadding = tight,
                    modifier = Modifier.weight(1f),
                ) { Text("Crop / flatten", maxLines = 1) }
                OutlinedButton(
                    onClick = { vm.enterStraighten() },
                    enabled = !p.loading,
                    contentPadding = tight,
                    modifier = Modifier.weight(1f),
                ) { Text("Straighten", maxLines = 1) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.undoArea() },
                    enabled = areaCount > 0,
                    contentPadding = tight,
                    modifier = Modifier.weight(1f),
                ) { Text("Undo", maxLines = 1) }
                OutlinedButton(
                    onClick = { vm.clearAreas() },
                    enabled = areaCount > 0,
                    contentPadding = tight,
                    modifier = Modifier.weight(1f),
                ) { Text("Clear", maxLines = 1) }
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { columnsMenu = true },
                        contentPadding = tight,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Columns ▾", maxLines = 1) }
                    DropdownMenu(expanded = columnsMenu, onDismissRequest = { columnsMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Whole page (no areas)") },
                            onClick = { columnsMenu = false; vm.splitColumns(1) },
                        )
                        DropdownMenuItem(
                            text = { Text("2 columns") },
                            onClick = { columnsMenu = false; vm.splitColumns(2) },
                        )
                        DropdownMenuItem(
                            text = { Text("3 columns") },
                            onClick = { columnsMenu = false; vm.splitColumns(3) },
                        )
                    }
                }
                if (p.pageCount > 1) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { moreMenu = true },
                            contentPadding = tight,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("More ▾", maxLines = 1) }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Copy these areas to all pages") },
                                onClick = { moreMenu = false; vm.copyAreasToAll() },
                            )
                            DropdownMenuItem(
                                text = { Text("Rotate all pages") },
                                onClick = { moreMenu = false; vm.rotateAll() },
                            )
                        }
                    }
                }
            }

            Text(
                text = if (areaCount == 0) {
                    "Drag on the page to select an area. With no area drawn, the whole page is read."
                } else {
                    "$areaCount area${if (areaCount > 1) "s" else ""} on this page, read in numbered order."
                },
                style = MaterialTheme.typography.bodySmall,
            )

            Button(
                onClick = { vm.extract() },
                enabled = rangeOk && !p.loading,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    when {
                        p.pageCount == 1 -> "Extract text"
                        p.scope == PageScope.ALL -> "Extract all ${p.pageCount} pages"
                        p.scope == PageScope.CURRENT -> "Extract this page"
                        else -> "Extract selected pages"
                    }
                )
            }
        }
    }
}

@Composable
private fun CropControls(vm: OcrViewModel, p: PreviewState) {
    Surface(tonalElevation = 3.dp) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "Drag each corner onto a corner of the page. The page is then flattened into a straight rectangle.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.autoCrop() },
                    enabled = !p.detecting,
                    modifier = Modifier.weight(1f),
                ) { Text(if (p.detecting) "Finding…" else "Auto crop", maxLines = 1) }
                OutlinedButton(
                    onClick = { vm.resetCrop() },
                    modifier = Modifier.weight(1f),
                ) { Text("Reset", maxLines = 1) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.cancelEdit() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(onClick = { vm.applyCrop() }, enabled = !p.detecting, modifier = Modifier.weight(1f)) { Text("Apply") }
            }
        }
    }
}

@Composable
private fun StraightenControls(vm: OcrViewModel, p: PreviewState) {
    Surface(tonalElevation = 3.dp) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "Turn by ${"%+.1f".format(Locale.US, p.editAngle)}°. Use the red lines to check that the text runs level.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Slider(
                value = p.editAngle,
                onValueChange = { vm.setEditAngle(it) },
                valueRange = -15f..15f,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.autoStraighten() },
                    enabled = !p.detecting,
                    modifier = Modifier.weight(1f),
                ) { Text(if (p.detecting) "Measuring…" else "Auto straighten", maxLines = 1) }
                OutlinedButton(
                    onClick = { vm.setEditAngle(0f) },
                    modifier = Modifier.weight(1f),
                ) { Text("Reset", maxLines = 1) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.cancelEdit() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(onClick = { vm.applyStraighten() }, enabled = !p.detecting, modifier = Modifier.weight(1f)) { Text("Apply") }
            }
        }
    }
}

// ----- the page and what is drawn on it ---------------------------------------------------------------

private class FitBox(val left: Float, val top: Float, val width: Float, val height: Float)

/** Where an image of [bw] x [bh] is drawn inside a [cw] x [ch] container, scaled to fit and centred. */
private fun fitBox(cw: Float, ch: Float, bw: Int, bh: Int): FitBox {
    val s = min(cw / bw, ch / bh)
    val w = bw * s
    val h = bh * s
    return FitBox((cw - w) / 2f, (ch - h) / 2f, w, h)
}

/** Turns a drag from [a] to [b] (screen pixels) into a rectangle on the page; null if it is too small. */
private fun toNorm(a: Offset, b: Offset, container: IntSize, image: ImageBitmap): NormRect? {
    val box = fitBox(container.width.toFloat(), container.height.toFloat(), image.width, image.height)
    fun nx(x: Float) = ((x - box.left) / box.width).coerceIn(0f, 1f)
    fun ny(y: Float) = ((y - box.top) / box.height).coerceIn(0f, 1f)
    val left = min(nx(a.x), nx(b.x))
    val right = maxOf(nx(a.x), nx(b.x))
    val top = min(ny(a.y), ny(b.y))
    val bottom = maxOf(ny(a.y), ny(b.y))
    return if (right - left < 0.03f || bottom - top < 0.015f) null else NormRect(left, top, right, bottom)
}

@Composable
private fun PageCanvas(
    image: ImageBitmap?,
    areas: List<NormRect>,
    onAdd: (NormRect) -> Unit,
    modifier: Modifier = Modifier,
) {
    var drag by remember { mutableStateOf<Pair<Offset, Offset>?>(null) }
    val add by rememberUpdatedState(onAdd)
    val label = remember {
        Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
    }

    Canvas(
        modifier = modifier.pointerInput(image) {
            val img = image ?: return@pointerInput
            detectDragGestures(
                onDragStart = { start -> drag = start to start },
                onDrag = { change, _ ->
                    change.consume()
                    drag = drag?.let { it.first to change.position }
                },
                onDragEnd = {
                    drag?.let { (a, b) -> toNorm(a, b, size, img)?.let { add(it) } }
                    drag = null
                },
                onDragCancel = { drag = null },
            )
        },
    ) {
        val img = image ?: return@Canvas
        val box = fitBox(size.width, size.height, img.width, img.height)
        drawImage(
            image = img,
            dstOffset = IntOffset(box.left.roundToInt(), box.top.roundToInt()),
            dstSize = IntSize(box.width.roundToInt(), box.height.roundToInt()),
        )

        val stroke = Stroke(width = 3.dp.toPx())
        areas.forEachIndexed { i, a ->
            val topLeft = Offset(box.left + a.left * box.width, box.top + a.top * box.height)
            val sz = Size((a.right - a.left) * box.width, (a.bottom - a.top) * box.height)
            drawRect(color = AreaBlue.copy(alpha = 0.18f), topLeft = topLeft, size = sz)
            drawRect(color = AreaBlue, topLeft = topLeft, size = sz, style = stroke)

            val r = 12.dp.toPx()
            val center = Offset(topLeft.x + r + 2.dp.toPx(), topLeft.y + r + 2.dp.toPx())
            drawCircle(color = AreaBlue, radius = r, center = center)
            label.textSize = r * 1.15f
            drawContext.canvas.nativeCanvas.drawText("${i + 1}", center.x, center.y + label.textSize * 0.35f, label)
        }

        drag?.let { (a, b) ->
            val topLeft = Offset(min(a.x, b.x), min(a.y, b.y))
            val sz = Size(abs(a.x - b.x), abs(a.y - b.y))
            drawRect(color = AreaBlue.copy(alpha = 0.18f), topLeft = topLeft, size = sz)
            drawRect(color = AreaBlue, topLeft = topLeft, size = sz, style = stroke)
        }
    }
}

/** Screen position of each page corner (top-left, top-right, bottom-right, bottom-left). */
private fun cornerOffsets(q: Quad, box: FitBox): List<Offset> =
    listOf(q.tl, q.tr, q.br, q.bl).map { Offset(box.left + it.x * box.width, box.top + it.y * box.height) }

private fun moveCorner(q: Quad, index: Int, p: Pt): Quad = when (index) {
    0 -> q.copy(tl = p)
    1 -> q.copy(tr = p)
    2 -> q.copy(br = p)
    else -> q.copy(bl = p)
}

/** The photo with four draggable corner handles; the outside of the chosen page is dimmed. */
@Composable
private fun CropCanvas(
    image: ImageBitmap?,
    quad: Quad,
    onChange: (Quad) -> Unit,
    modifier: Modifier = Modifier,
) {
    val notify by rememberUpdatedState(onChange)
    val latest by rememberUpdatedState(quad)
    var active by remember { mutableStateOf(-1) }

    Canvas(
        modifier = modifier.pointerInput(image) {
            val img = image ?: return@pointerInput
            detectDragGestures(
                onDragStart = { start ->
                    val box = fitBox(size.width.toFloat(), size.height.toFloat(), img.width, img.height)
                    val corners = cornerOffsets(latest, box)
                    active = corners.indices.minByOrNull { (corners[it] - start).getDistance() } ?: -1
                },
                onDrag = { pointer, _ ->
                    pointer.consume()
                    val i = active
                    if (i >= 0) {
                        val box = fitBox(size.width.toFloat(), size.height.toFloat(), img.width, img.height)
                        val nx = ((pointer.position.x - box.left) / box.width).coerceIn(0f, 1f)
                        val ny = ((pointer.position.y - box.top) / box.height).coerceIn(0f, 1f)
                        notify(moveCorner(latest, i, Pt(nx, ny)))
                    }
                },
                onDragEnd = { active = -1 },
                onDragCancel = { active = -1 },
            )
        },
    ) {
        val img = image ?: return@Canvas
        val box = fitBox(size.width, size.height, img.width, img.height)
        drawImage(
            image = img,
            dstOffset = IntOffset(box.left.roundToInt(), box.top.roundToInt()),
            dstSize = IntSize(box.width.roundToInt(), box.height.roundToInt()),
        )

        val c = cornerOffsets(quad, box)
        val outline = Path().apply {
            moveTo(c[0].x, c[0].y)
            lineTo(c[1].x, c[1].y)
            lineTo(c[2].x, c[2].y)
            lineTo(c[3].x, c[3].y)
            close()
        }
        // Dim everything outside the page outline.
        val dim = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(box.left, box.top, box.left + box.width, box.top + box.height))
            addPath(outline)
        }
        drawPath(dim, Color.Black.copy(alpha = 0.45f))
        drawPath(outline, HandleTeal, style = Stroke(width = 3.dp.toPx()))

        val r = 11.dp.toPx()
        c.forEach { p ->
            drawCircle(color = Color.White, radius = r, center = p)
            drawCircle(color = HandleTeal, radius = r, center = p, style = Stroke(width = 3.dp.toPx()))
        }
    }
}

/** The flattened page turned by the slider's angle, with red guide lines to judge whether text is level. */
@Composable
private fun StraightenCanvas(
    image: ImageBitmap?,
    angle: Float,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val img = image ?: return@Canvas
        val box = fitBox(size.width, size.height, img.width, img.height)
        val center = Offset(box.left + box.width / 2f, box.top + box.height / 2f)

        clipRect(box.left, box.top, box.left + box.width, box.top + box.height) {
            drawRect(color = Color.White, topLeft = Offset(box.left, box.top), size = Size(box.width, box.height))
            rotate(degrees = angle, pivot = center) {
                drawImage(
                    image = img,
                    dstOffset = IntOffset(box.left.roundToInt(), box.top.roundToInt()),
                    dstSize = IntSize(box.width.roundToInt(), box.height.roundToInt()),
                )
            }
            val guide = Color.Red.copy(alpha = 0.45f)
            val line = 1.dp.toPx()
            for (k in 1..15) {
                val y = box.top + box.height * k / 16f
                drawLine(guide, Offset(box.left, y), Offset(box.left + box.width, y), strokeWidth = line)
            }
            for (k in 1..7) {
                val x = box.left + box.width * k / 8f
                drawLine(guide, Offset(x, box.top), Offset(x, box.top + box.height), strokeWidth = line)
            }
        }
    }
}
