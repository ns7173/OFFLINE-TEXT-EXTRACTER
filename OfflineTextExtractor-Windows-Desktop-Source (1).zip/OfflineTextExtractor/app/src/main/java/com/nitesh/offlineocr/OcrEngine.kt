package com.nitesh.offlineocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Script { DEVANAGARI, LATIN }

/** Plain text for the editor, plus every word with its position for Word/Excel export. */
class OcrResult(val text: String, val page: OcrPage)

/**
 * Thin wrapper over the bundled ML Kit recognizers. Everything runs on-device.
 * The Devanagari recognizer reads Devanagari and Latin text, so it is the right
 * default for Hindi documents that also contain English words and numbers.
 */
class OcrEngine {
    private var devanagari: TextRecognizer? = null
    private var latin: TextRecognizer? = null

    private fun recognizerFor(script: Script): TextRecognizer = when (script) {
        Script.DEVANAGARI -> devanagari ?: TextRecognition
            .getClient(DevanagariTextRecognizerOptions.Builder().build())
            .also { devanagari = it }
        Script.LATIN -> latin ?: TextRecognition
            .getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .also { latin = it }
    }

    suspend fun recognize(bitmap: Bitmap, script: Script): OcrResult {
        val image = InputImage.fromBitmap(bitmap, 0)
        val result = recognizerFor(script).process(image).awaitResult()
        return OcrResult(OcrText.normalizeDigits(result.text), toPage(result, bitmap.width, bitmap.height))
    }

    fun close() {
        devanagari?.close()
        latin?.close()
        devanagari = null
        latin = null
    }
}

/** Flattens ML Kit's block > line > element tree into positioned words. */
private fun toPage(text: Text, width: Int, height: Int): OcrPage {
    val words = ArrayList<OcrWord>()
    for (block in text.textBlocks) {
        for (line in block.lines) {
            if (line.elements.isEmpty()) {
                line.boundingBox?.let { words.add(it.toWord(line.text)) }
            } else {
                for (element in line.elements) {
                    val box = element.boundingBox ?: line.boundingBox ?: continue
                    words.add(box.toWord(element.text))
                }
            }
        }
    }
    return OcrPage(width, height, words)
}

private fun Rect.toWord(text: String) =
    OcrWord(OcrText.normalizeDigits(text), left.toFloat(), top.toFloat(), right.toFloat(), bottom.toFloat())

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}
